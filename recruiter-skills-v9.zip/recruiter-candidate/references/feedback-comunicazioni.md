# Feedback, Comunicazioni Delicate e Gestione delle Relazioni

## COME USARE QUESTO FILE
Usare quando devi comunicare un feedback al cliente o al candidato, gestire un ritiro,
un rifiuto d'offerta, o spingere un candidato che tentenna. Contiene script pronti,
principi di comunicazione e logica dietro ogni situazione.

---

## PARTE A — FEEDBACK AL CLIENTE

### A1. Feedback positivo sul candidato

Il feedback positivo non è solo "è andato bene". È un'occasione per:
- Confermare la qualità del lavoro di scouting
- Creare urgenza se il candidato è competitivo
- Preparare il cliente alla fase successiva senza lasciargli tempo per perdere momentum

**Struttura del messaggio:**
1. Segnale positivo chiaro (non vago)
2. Evidenza concreta che lo supporta
3. Segnale di urgenza reale (altri processi, motivazione contingente)
4. Next step proposto con timeline

**Esempio:**
"Ciao [Nome], ho appena finito di sentire [Candidato] — uscito molto bene.
[Evidenza specifica: es. "La gestione del team è esattamente quella che cercavate —
ha fatto PIP documentati, obiettivi co-costruiti, team fino a 11 persone."]
Ha altri processi attivi e si aspetta feedback entro [data].
Se siete allineati, vi propongo di schedulare il primo step entro questa settimana
per non perderlo. Vi mando la scorecard in giornata."

**Cose da evitare:**
- "È andato benissimo!" senza evidenze → suona commerciale, non consulenziale
- Non menzionare altri processi → il cliente non sente urgenza
- Mandare solo la scorecard senza una call to action → il cliente procrastina

---

### A2. Feedback negativo sul candidato — tono delicato

Il feedback negativo al cliente va dato con chiarezza ma senza distruggere il candidato.
Il cliente deve poter prendere una decisione informata, non sfogare una delusione.

**Principio:** spiegare il mismatch in modo oggettivo, non giudicante.
Il candidato potrebbe tornare utile per un'altra posizione — mai bruciarlo.

**Struttura:**
1. Ringraziare il cliente per il feedback
2. Tradurre il feedback in termini oggettivi (non "non ci ha convinto" → mai)
3. Indicare cosa si cercherà di diverso nei prossimi profili
4. Mantenere il momentum ("sto già guardando altri profili")

**Esempio (feedback negativo ricevuto):**
"Grazie per il riscontro. Ho capito — la profondità tecnica su [stack specifico]
non era al livello atteso, in particolare su [dettaglio]. Lo tengo presente
per i prossimi profili che sto valutando. Ho già 2-3 profili interessanti
che voglio scremare questa settimana — vi aggiorno non appena ho qualcosa di solido."

**Se il feedback è generico ("non ci ha convinto"):**
Chiedere specificità prima di riportarlo: "Capisco. Può dirmi su quale area
non ha convinto — il tecnico, il people management, la motivazione?
Mi serve per calibrare i prossimi profili."
Se non specificano, ricostruire il feedback internamente (vedi Parte B4).

---

### A3. Come comunicare la situazione del mercato al cliente

Quando il cliente ha aspettative irrealistiche — RAL bassa, requisiti impossibili,
processo troppo lungo — il recruiter deve essere il "portatore di realtà", non
il yes-man. Questo è il momento più delicato del rapporto commerciale.

**Principio:** dati, non opinioni. Il mercato ha una logica — mostrarla.

#### Caso 1 — RAL sotto mercato

"Voglio essere trasparente su una cosa che sto osservando nel mercato.
Per questo stack e questa seniority, il range che vedo nella ricerca
è [X-Y]. Con [budget del cliente], il pool si restringe significativamente —
stiamo già escludendo una fascia importante di candidati.
Non è un problema insormontabile, ma devo dirvelo chiaramente:
potremmo allungare i tempi o trovare profili leggermente più junior.
Se volete, posso prepararvi un confronto rapido su cosa offre il mercato
per ruoli simili. Così decidete con dati in mano."

**Dopo l'analisi, se il cliente vuole restare fermo:**
"Capisco. Procedo su questo budget — ma vi tengo aggiornati se noto
che i candidati migliori vanno altrove per questioni economiche.
In quel caso torniamo a parlarne."

#### Caso 2 — Il cliente ha una cattiva reputazione sul mercato

Questa è la conversazione più difficile. Va fatta con tatto assoluto,
in modo privato (mai via email), e basandosi su evidenze concrete.

"Voglio condividere qualcosa che mi sta arrivando dal mercato e che
ritengo importante che voi sappiate. Ho parlato con alcuni profili
e ho ricevuto feedback spontanei su [situazione specifica — es. "il processo
di selezione era molto lungo e senza feedback", o "c'era un'aspettativa
di disponibilità fuori orario non comunicata"]. Non vi dico questo per
criticarvi, ma perché nel mercato IT di Milano i candidati si conoscono
e le esperienze circolano. Se c'è qualcosa che possiamo fare per migliorare
la percezione del vostro employer brand durante il processo, sono qui
per aiutarvi a costruirlo — è anche nel mio interesse che la ricerca vada a buon fine."

**Cosa NON dire mai:**
- "I candidati dicono che siete una brutta azienda" → attacco diretto, crea difensività
- "Ho sentito brutte cose" → vago e non costruttivo
- Mandarlo per iscritto → rimane traccia, può creare tensione

**Cosa fare dopo:**
- Proporre azioni concrete: processo di feedback strutturato, comunicazione più rapida, ecc.
- Monitorare se la situazione migliora
- Se il problema persiste e sta bloccando la ricerca: valutare se continuare il mandato

#### Caso 3 — Bacino ristretto per territorio o stack raro

"Voglio aggiornarvi sulla situazione del mercato per questa ricerca.
Il pool di candidati con [stack/requisiti specifici] nell'area [territorio]
è più ristretto di quanto mi aspettassi — siamo nell'ordine di [stima]
profili davvero allineati. Di questi, molti sono già occupati con processi
attivi. Non voglio promettervi tempi che non riesco a garantire.
Le opzioni che vedo sono: [1] allargare il raggio geografico, [2] flessibilizzare
uno dei requisiti non core, [3] allungare la timeline con aspettative chiare.
Come volete procedere?"

---

### A4. Come comunicare quando il candidato si ritira — molto delicato

Il ritiro del candidato è una delle comunicazioni più scomode al cliente.
Il recruiter ci mette la faccia — ma non è colpa sua, e non deve esserlo.

**Principio:** trasparenza immediata + soluzione già pronta.
Non aspettare. Non minimizzare. Non sparire.

**Struttura:**
1. Comunicare subito (non aspettare il "momento giusto")
2. Dare la motivazione con il livello di dettaglio appropriato
3. Non colpevolizzare il candidato pubblicamente
4. Proporre la strada avanti immediatamente

**Esempio (ritiro prima della firma):**
"Ciao [Nome], devo aggiornarvi su una situazione che si è sviluppata nelle ultime ore.
[Candidato] ha deciso di non procedere con voi — ha ricevuto un'altra offerta
che ha scelto di accettare [o: ha deciso di restare nella sua azienda attuale].
So che è una notizia inaspettata e capisco la frustrazione, soprattutto
dopo l'investimento che avete messo nel processo.

Ho già riattivato la pipeline — ho altri [X] profili che avevo tenuto in stand-by
e uno in particolare che ritengo solido. Vi propongo di sentirci questa settimana
per capire se procedere e con quale timeline.

Sono a disposizione per una call quando volete."

**Cosa NON dire:**
- "Il candidato ha cambiato idea all'ultimo" → suona come una scusa
- "Non è colpa mia" → anche se vero, difensivo
- Mandare un messaggio freddo e sparire → brucia il rapporto

**Livello di dettaglio sulla motivazione:**
- Se il ritiro è per controfferta: dirlo chiaramente
- Se è per motivi personali (partner, famiglia, salute): "motivi personali" senza dettagli
- Se è per dubbi sull'azienda cliente: trovare un modo diplomatico senza essere disonesti
  ("ha rivalutato la sua situazione attuale dopo un confronto approfondito")
  — mai mentire, ma non sempre la verità integrale serve al rapporto

---

### A5. Come comunicare quando il candidato rifiuta l'offerta

Diverso dal ritiro: qui la JO era stata mandata e il candidato dice no.
Il cliente ha già investito molto — l'impatto emotivo è più forte.

**Prima di comunicarlo al cliente — chiamare il candidato:**
Capire il motivo reale. Il no spesso nasconde qualcosa di risolvibile:
- RAL non sufficiente → si può riaprire la trattativa?
- Dubbi su un aspetto specifico → si può chiarire?
- Altra offerta → si può competere?
- Motivazione non c'era davvero → non c'è nulla da fare

**Se non è risolvibile, comunicare al cliente:**
"Ciao [Nome], [Candidato] ha riflettuto sull'offerta e ha deciso di non accettare.
Ho parlato con lui in dettaglio — il motivo principale è [motivazione appropriata].
Ho provato a capire se c'era margine per risolvere la situazione,
ma la sua decisione è definitiva.

Capisco che sia frustrante dopo un iter così lungo.
[Se pipeline attiva:] Ho già altri profili che stavo valutando in parallelo —
voglio sentirvi questa settimana per capire se e come procedere."

**Se il cliente è arrabbiato:**
Lasciarlo sfogare. Non difendersi immediatamente. Poi:
"Hai tutto il diritto di essere deluso — è stato un percorso lungo.
Quello che posso fare adesso è [azione concreta]. Quando sei pronto,
parliamoci e decidiamo insieme i prossimi passi."

---

## PARTE B — FEEDBACK AI CANDIDATI

### B1. Feedback positivo — semplice ma da gestire bene

Il feedback positivo è anche il momento per preparare il candidato al next step
e verificare la sua motivazione reale. Non limitarsi a "sei andato bene".

**Struttura:**
1. Feedback positivo con specificità
2. Segnale su cosa aspettarsi dopo
3. Domanda di verifica motivazione

**Esempio:**
"Ciao [Nome], ho appena sentito il cliente — il riscontro è molto positivo.
In particolare hanno apprezzato [dettaglio specifico].
Stanno valutando anche altri profili ma ho un buon presentimento.

Volevo chiederti: dopo tutti i passaggi che hai fatto, com'è il tuo interesse
per questa opportunità da 1 a 10? E cosa ti mancherebbe per arrivare a 10?"

---

### B2. Feedback negativo con evidenze — diretto ma costruttivo

Quando si ha un feedback specifico dal cliente, usarlo per dare un KO
che sia utile al candidato e non bruci la relazione.

**Principio:** il feedback negativo ben dato è un regalo professionale.
Un candidato che riceve un KO con motivazione concreta ti ricorderà positivamente.

**Struttura:**
1. Ringraziare per il tempo investito
2. Dare il feedback in modo specifico e non personale
3. Separare il "non è giusto per questo ruolo" da "non è valido come professionista"
4. Lasciare porta aperta per il futuro

**Esempio:**
"Ciao [Nome], grazie per il tempo che hai dedicato a questo processo.
Ho ricevuto il feedback dal cliente — purtroppo hanno deciso di procedere
con un altro profilo. Il motivo che mi hanno dato è [feedback specifico
de-personalizato: es. "cercavano un'esperienza più hands-on su Kubernetes
in produzione, che nel tuo percorso era più supervisionale"].

Voglio essere chiaro: questo non è un giudizio sulla tua seniority —
è semplicemente un mismatch con le loro esigenze specifiche in questo momento.
Ti tengo in mente per altre opportunità — il tuo profilo su [punti di forza]
è interessante per contesti diversi."

---

### B3. Feedback negativo senza evidenze — come costruirlo

Situazione molto comune: il cliente dice "KO" o "non procediamo" senza motivazione.
Il recruiter deve costruire un feedback plausibile, coerente con i dati che ha.

**Input disponibili:** transcript kick-off + CV candidato + transcript colloquio (se fatto)

**Processo di costruzione:**

1. Identificare i must have del kick-off che il candidato non copriva pienamente
2. Identificare eventuali gap emersi nel colloquio (tecnici o motivazionali)
3. Scegliere UN motivo principale (non una lista) — deve essere credibile, non una lista di difetti
4. Formularlo in modo oggettivo e de-personalizzato

**Esempi di feedback costruiti:**

*Gap tecnico:*
"Il cliente stava cercando un'esperienza più diretta su [stack specifico] —
nel tuo percorso era presente ma in un contesto diverso da quello che gestiscono loro."

*Gap di seniority percepita:*
"Il team in questa fase cercava qualcuno con esperienza pregressa in contesti
di scala simile — il tuo background è solido ma viene da realtà più piccole."

*Gap motivazionale (mai dire che sembrava poco motivato):*
"Hanno privilegiato un profilo con una motivazione molto specifica per il loro settore/prodotto —
è stato un elemento determinante nella scelta finale."

*Gap logistico (se c'era):*
"La disponibilità per la presenza richiesta era un elemento critico per loro
e il tuo setup attuale rendeva la cosa più complessa."

**Regole per costruire feedback plausibili:**
- Deve essere basato su qualcosa di reale emerso nel processo — non inventato dal nulla
- Un solo motivo principale — più motivi suonano come una lista di scuse
- Mai attaccare caratteristiche personali (carattere, modo di comunicare, età)
- Mai contraddire quello che hai detto al candidato durante il colloquio
- Deve lasciare la porta aperta ("non è il momento giusto" non "non sei adatto")

---

### B4. Candidato che tentenna — unica speranza di placement

Questa è la situazione più delicata in assoluto. Il candidato è il migliore (o l'unico)
che hai per quel mandato, sta esitando, e tu hai bisogno che firmi.

**La trappola:** l'urgenza del recruiter non deve trasparire.
Se il candidato percepisce che sei disperato, perde fiducia nell'opportunità.
La pressione mal gestita fa scappare il candidato — o peggio, fa firmare
qualcuno che poi non si presenta il primo giorno.

**Principio:** aiutare il candidato a prendere la decisione giusta PER LUI,
non spingerlo verso la decisione giusta per te.

#### Step 1 — Capire il vero dubbio

Non procedere a spingere prima di aver capito cosa c'è sotto.
"Ho la sensazione che ci sia ancora qualcosa che non hai smarcato del tutto.
Potrebbe condividere con me cosa la frena? Non sono qui per convincerla —
voglio aiutarla a fare la scelta giusta per lei."

Aspettare la risposta vera. Spesso il candidato che tentenna ha:
- Un dubbio specifico e risolvibile (aspetto del contratto, chiarimento sul ruolo)
- Una paura generica del cambiamento
- Un'altra offerta che non ha detto
- Pressione esterna (famiglia, partner)
- Non era convinto davvero — ma non sa come dirlo

#### Step 2 — Risposta in base al dubbio reale

**Dubbio risolvibile:**
Portarlo al cliente. "Questo posso chiarirlo. Mi dà un giorno per
verificare con il cliente e tornare da lei con una risposta?"

**Paura del cambiamento:**
"Capisco. Cambiare dopo [X anni] non è banale — è normale sentire
un po' di resistenza anche quando l'opportunità è giusta.
Le chiedo una cosa sola: guardando a questa opportunità senza la paura
del cambiamento, la vede positivamente?"
Se la risposta è sì: "Allora il tema è il coraggio di fare il salto,
non l'opportunità in sé. È una riflessione che solo lei può fare —
ma sappia che da quello che ho visto, i presupposti ci sono."

**Altra offerta non dichiarata:**
"Ho la sensazione che ci sia qualche altro elemento in gioco che non mi ha ancora detto.
È normale — ma se mi aiuta a capire il quadro completo, posso aiutarla meglio."
Se ammette l'altra offerta: gestire con il framework comparativo (90%/50%/5%).

**Non era convinto davvero:**
"Le faccio una domanda diretta: se togliamo la RAL dall'equazione,
questo è un lavoro che vorrebbe fare? Se la risposta è no, è meglio
saperlo adesso — per lei e per il cliente."
Se dice no o tergiversa: non spingere oltre. Un candidato non convinto
che firma è un problema futuro garantito.

#### Step 3 — Creare il senso di urgenza (solo se reale)

L'urgenza deve essere vera — mai inventata. Se è vera, usarla:
"Voglio essere trasparente: il cliente sta valutando anche un altro profilo
e mi ha chiesto una risposta entro [data]. Non voglio metterla sotto pressione,
ma voglio che abbia tutte le informazioni per decidere con chiarezza."

#### Step 4 — La domanda di chiusura

Quando il candidato ha smarcato i dubbi e sembra pronto:
"Se il cliente arriva a [condizione che ha richiesto], può garantirmi la firma?
Ho bisogno di sapere se posso andare avanti con fiducia da entrambe le parti."

Se dice sì: procedere.
Se dice "probabilmente sì" o "credo di sì": non è abbastanza.
"Capisco. Ma ho bisogno di un sì netto prima di tornare dal cliente —
non voglio bruciare il rapporto con loro se poi non si chiude.
Cosa le manca per arrivare a un sì?"

#### Step 5 — Quando smettere di spingere

Spingere oltre il punto giusto fa danni. Smettere quando:
- Il candidato ha detto no in modo chiaro
- Il candidato dà segnali evidenti di non voler procedere ma non lo dice
  (non risponde, trova sempre nuovi dubbi, rimanda senza motivo concreto)
- Il dubbio fondamentale è sulla motivazione reale ("non sono sicuro di volere questo lavoro")

In questi casi: comunicare onestamente al cliente e riattivare la pipeline.
È meglio perdere un placement che bruciare la fiducia del cliente
con qualcuno che non si presenterà.

---

## RIEPILOGO — TONO PER OGNI SITUAZIONE

| Situazione | Tono | Cosa non fare |
|---|---|---|
| Feedback positivo al cliente | Entusiasta ma con evidenze, urgenza reale | Vago, senza next step |
| Feedback negativo al cliente | Oggettivo, costruttivo, con strada avanti | Giudicare il candidato, sparire |
| Situazione mercato difficile | Consulenziale, dati alla mano | Dire solo problemi senza soluzioni |
| Reputazione negativa cliente | Privato, basato su evidenze, propositivo | Accusare, scrivere via email |
| Candidato che si ritira | Immediato, empatico con cliente, soluzione pronta | Aspettare, minimizzare, sparire |
| Rifiuto offerta | Trasparente, con motivazione, next step | Difendersi, colpevolizzare |
| Feedback KO con evidenze | Specifico, de-personalizzato, porta aperta | Lista di difetti, attacchi personali |
| Feedback KO senza evidenze | Costruito su dati reali, un motivo solo | Inventare, contraddire sé stessi |
| Candidato che tentenna | Paziente, curioso, senza trasmettere urgenza | Pressare, sembrare disperato |
