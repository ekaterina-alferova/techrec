# Gestione Imprevisti, Obiezioni e Negoziazione

## COME USARE QUESTO FILE
Questo file copre tutto ciò che va storto — e come si raddrizza.
È la parte che i manuali di recruitment non insegnano.
Usarlo quando: il candidato sparisce, il cliente obietta, la RAL non torna,
o senti che c'è qualcosa sotto che il candidato non dice.

---

## 1. GHOSTING

### Ghosting del candidato

**Segnali predittivi (prima che sparisca):**
- Risponde sempre in ritardo, in modo monosillabico
- Non ha ancora comunicato la data di uscita al suo datore
- Dice "ci penso" senza chiedere chiarimenti specifici
- Ha ricevuto feedback positivi ma non mostra entusiasmo
- Non ha risposto alla domanda "quanto daresti a questa opportunità da 1 a 10?"

**Azioni preventive:**
- Non lasciare mai il candidato senza un next step concreto con deadline ("la sento giovedì")
- Chiedere il numero WhatsApp dal primo contatto — il telefono converte più della mail
- Creare un senso di scarsità reale: "stanno valutando anche altri profili, ho bisogno di sapere"
- Non aspettare — se non risponde entro 48h, richiamare

**Protocollo di recupero:**
1. Primo tentativo: WhatsApp breve e diretto. "Ciao [Nome], ti cerco per aggiornarti. Riesci a sentirci oggi o domani?"
2. Secondo tentativo (48h dopo): chiamata. Non lasciare messaggi vocali lunghi.
3. Terzo tentativo (5 giorni dopo): messaggio finale. "Capisco che i tempi possano non essere giusti. Se cambia qualcosa in futuro, resto disponibile." — lascia una porta aperta, non brucia il ponte.
4. Oltre il terzo tentativo: smettere. Lo stalking danneggia la reputazione.

**Se sparisce dopo aver accettato verbalmente:**
Chiamata diretta, tono calmo: "Ho ricevuto il tuo silenzio dopo la nostra conversazione.
Capisco che possono essere successe cose — puoi dirmi cosa è cambiato?
Preferisco saperlo chiaramente piuttosto che andare avanti con il cliente in modo errato."
Se non risponde: comunicare al cliente con professionalità, senza colpevolizzare il candidato.

---

### Ghosting del cliente

**Segnali predittivi:**
- Non risponde entro 48h dopo la presentazione candidati
- Feedback sempre generici ("ci stiamo pensando")
- Le riunioni interne si moltiplicano senza output
- Il referente è cambiato o non è più il decisore

**Protocollo di recupero:**
1. Primo contatto: email o messaggio con recap e domanda diretta. "Ho 3 candidati in attesa di feedback — posso avere un aggiornamento entro [data]? Non voglio perderli."
2. Secondo contatto (3 giorni): "Uno dei candidati presentati ha ricevuto un'altra offerta. Ha senso procedere o il processo si è bloccato per ragioni interne?"
3. Se il cliente è davvero fermo: capire se è un blocco decisionale, un budget freeze, o un cambiamento interno. Proporre una call di 15 minuti per capire lo stato.

**Non lasciare mai i candidati in attesa senza un aggiornamento** — anche se non hai notizie.
"Non ho ancora feedback dal cliente ma sto sollecitando — ti tengo aggiornato."

---

## 2. OBIEZIONI DEL CLIENTE

### "È troppo vecchio" (age bias — es. EM di 42-44 anni, cliente vuole max 40)

**Prima risposta:** non difendere immediatamente. Capire cosa c'è dietro.
"Capisco. Cosa la preoccupa specificamente dell'età in questo ruolo?"
Le risposte tipiche:
- "Non si adatta alla cultura giovane" → portare evidenze concrete di come il candidato lavora con team junior
- "Costerà troppo" → mostrare che il budget è allineato
- "Non sarà motivato a crescere" → portare le sue motivazioni reali dalla scorecard

**Argomenti da usare:**
- L'età non correla con la performance in ruoli people-first — la maturità professionale è un asset
- Un EM di 44 anni che gestisce sviluppatori di 28-32 anni ha già navigato queste dinamiche
- Il rischio opposto: un EM di 31 anni senza sufficiente autorevolezza su un team senior
- Citare il caso specifico: "Danilo ha gestito team fino a 11 persone e i suoi ex-diretti sono in big tech. L'età non è mai stata un limite nella sua carriera."

**Se il cliente insiste nonostante le evidenze:**
Documentare l'obiezione. Può essere discriminazione d'età (vietata per legge). Non portare altri candidati più giovani solo per compiacere il cliente — è complice.

---

### "La RAL è troppo alta" (il cliente vuole abbassare l'offerta in corso d'iter)

**Quando succede:** il candidato in colloquio ha rivelato la sua RAL attuale + desiderata e ora il cliente vuole usare la RAL attuale come ancora.

**Prima risposta:** non trasmettere l'obiezione al candidato prima di aver parlato col cliente.
"Posso chiederle su cosa basa questa valutazione? Il budget approvato era [X] — cosa è cambiato?"

**Argomenti:**
- "La RAL desiderata del candidato è [Y]. Il mercato per questo profilo è [Z]. Se offriamo meno, rischiamo di perderlo o di partire con lui già insoddisfatto."
- "Un engineering manager non è fungibile — trovarne un altro con questo livello di PM strutturato ci costerebbe altri 3-4 mesi."
- Se il budget è davvero limitato: esplorare compensazioni alternative (bonus di ingresso, vesting accelerato, titolo superiore, remote policy più flessibile)

**Regola ferrea:** non diventare mai il tramite di un'offerta che sai già che verrà rifiutata.
"Prima di trasmetterla, mi fa capire su quale logica si basa? Perché se so già che sarà un no, risparmio tempo a entrambi."

---

### "Non ci ha convinto" (feedback generico dopo il colloquio)

**Il feedback generico è inutile per tutti.** Aiutare il cliente a essere più specifico.
"Capisco. Può dirmi su quale area non ha convinto — il tech, il people management, la motivazione, o qualcos'altro? Mi aiuta a calibrare i profili successivi."

Se proprio non riesce a specificare: ricostruire il feedback in base ai punti di caduta
emersi nella tua scorecard e trasmetterlo al candidato in modo professionale.
"Il cliente ha valutato alcuni aspetti tecnici non allineati alle proprie aspettative" + dettaglio specifico ricostruito.

---

### "Volevamo qualcuno già operativo al 100% dal giorno 1"

**Risposta:** "Questo profilo ha [X anni di esperienza specifica]. Un periodo di ramping
del contesto aziendale è fisiologico per chiunque. Cosa intende esattamente con operativo?
Su quale parte si aspetta la curva più lunga?"
Se il cliente ha aspettative irrealistiche sul tempo di onboarding: affrontarlo direttamente.

---

## 3. NEGOZIAZIONE RAL CON IL CLIENTE

### Prima del kick-off
- Raccogliere sempre il budget prima di partire. Senza budget non si avvia la ricerca.
- Se esitano: "Mi da almeno una forchetta? Altrimenti rischio di presentare profili fuori range."
- Se il budget è basso rispetto al mercato: dirlo subito. "Per questo stack, il mercato Milano è [X-Y]. Con [Z] avremo difficoltà a trovare il profilo desiderato. Possiamo allargare il budget o flessibilizzare i requisiti?"

### Durante l'iter (candidato propone RAL più alta del budget)
- Non rifiutare immediatamente. "Lasci che le proponga questa situazione al cliente."
- Presentare al cliente con il contesto: "Il candidato è Tier 1 — il migliore che abbiamo visto. Chiede [X], che supera il budget di [Y]. Ecco perché vale la differenza: [evidenze dalla scorecard]."
- Proporre alternative: entry bonus, vesting più rapido, titolo superiore, review RAL a 6 mesi.

### Come strutturare la proposta alternativa
Se il cliente non può muovere la RAL base:
1. **Entry bonus una tantum:** spesso approvato più facilmente perché non aumenta il costo strutturale
2. **Aumento garantito a fine periodo di prova:** engagement e riduzione del rischio percepito
3. **MBO più alto:** sposta parte del costo a performance verification
4. **Remote policy più generosa:** valore percepito alto, costo zero per il cliente

---

## 4. NEGOZIAZIONE CON IL CANDIDATO IN FASE DI OFFERTA

### Il candidato chiede di più (counterproposal)

**Prima domanda interna:** la sua richiesta è nel range di mercato? Se sì, portarla al cliente.
Se è fuori range: "Capisco la sua richiesta. Posso portarla al cliente, ma le dico
già che supera il budget approvato di [X]. Cosa la porterebbe ad accettare anche
con la RAL che le è stata proposta?"

**La tecnica del floor commitment:**
"Se il cliente arriva a [X], mi può garantire la firma? Sì o no? Ho bisogno di saperlo
prima di mettere la mia faccia in questa trattativa."

**Se il candidato dice "forse":** non procedere. "Preferirei capire prima i dubbi —
se c'è qualcosa che non va nell'opportunità, è meglio sapere ora."

### Il candidato ha un'altra offerta (bidding war)

Non entrare in una guerra al ribasso automatica. Prima capire:
- "Può condividere i termini dell'altra offerta? Voglio fare un confronto onesto."
- Costruire l'analisi comparativa (tabella 90%/50%/5%) per entrambe le offerte
- Se l'altra offerta è genuinamente migliore: dirlo al cliente con i numeri. Decidono loro.
- Se il candidato usa l'altra offerta come leva senza intenzione reale: "Se il cliente
  eguaglia o supera l'altra offerta, può garantirmi la firma? Ho bisogno di una risposta chiara."

---

## 5. PSICOLOGIA DEL CANDIDATO — MOTIVAZIONI NASCOSTE

### Il candidato che dice di essere pronto ma non firma

**Cosa c'è sotto (lista non esaustiva):**
- **Partner/coniuge contrario:** "mia moglie/marito preferisce che rimanga dove sono" è rarissimo che venga detto spontaneamente. Domanda indiretta: "Ne ha parlato con le persone vicine a lei? Come la vedono?"
- **Paura del cambiamento mascherata da obiezioni razionali:** ogni obiezione che risolvi ne genera un'altra. Segnale: il candidato trova sempre un nuovo problema.
- **Controfferta interna già ricevuta o attesa:** "Ha parlato con il suo responsabile di questa situazione?" Se non l'ha fatto → rischio controfferta alto.
- **Il ruolo non lo convince davvero ma non lo dice:** "Scordiamo la RAL per un momento — è un lavoro che vorrebbe fare? Se la risposta è no, fermiamoci qui."
- **Timing sbagliato:** casa in vendita, figlio piccolo, genitore malato. Domanda diretta: "C'è qualcosa a livello personale che rende difficile un cambio in questo momento?"
- **Non si fida del cliente dopo i colloqui:** raccogliere sempre il feedback a caldo dopo ogni step. Cosa lo ha colpito? C'è qualcosa che lo ha preoccupato?

### Il segnale del punteggio 1-10

- **9-10:** candidato pronto, proceed
- **7-8:** ci sono dubbi — esplorarli prima di andare avanti
- **<7:** non portare l'offerta. "Le dico onestamente: con un 6, l'offerta verrà quasi certamente rifiutata. Preferirei capire cosa manca."
- **"Non lo so":** peggior risposta possibile — significa che non è convinto ma non vuole dire no

### Come spingere verso la firma senza pressare

**La tecnica del rischio condiviso:**
"Ha visto il cliente da più angolazioni. Ci ha parlato di persona, ha visto il prodotto, conosce il team. In base a quello che ha visto — non alla RAL — lo vede come un posto dove può crescere nei prossimi 3 anni?"
Se dice sì: "Allora cosa la frena?" — e si apre lo spazio per le motivazioni nascoste.

**La tecnica dello specchio:**
"Immagini tra 6 mesi, seduto alla scrivania di [azienda]. Come si sente?"
Se la risposta è positiva ma ha ancora dubbi: i dubbi sono gestibili, non strutturali.

**La tecnica della perdita:**
"Devo essere trasparente: il cliente sta valutando anche [altro profilo / ha una deadline].
Se aspettiamo ancora una settimana, rischiamo di perdere la finestra."
Usare solo se è vero — mai come pressione artificiale.

**Dopo ogni chiamata chiave:** mandare sempre un WhatsApp di follow-up con il recap
del next step e la data entro cui si aspetta una risposta. Riduce l'ambiguità e mantiene il momentum.

---

## 6. GHOSTING POST-FIRMA (candidato firma e poi non si presenta)

**Il 90% dei casi è prevenibile** con una call di check-in nella settimana tra firma e primo giorno.
"Come si sente? Ha già comunicato le dimissioni? Ci sono stati sviluppi?"

Se il candidato è stato contattato dal suo attuale datore con una controfferta:
"Capisco che sia una situazione difficile. Prima di prendere una decisione, può farmi sapere cosa le è stato offerto? Voglio assicurarmi che stia valutando le cose nella giusta prospettiva."

Se nonostante tutto non si presenta: comunicare immediatamente al cliente, 
offrire di riattivare la pipeline con priorità. Non sparire.

---

## 7. CLIENTE CHE CHIUDE POSIZIONI A PROCESSO AVANZATO

La situazione: il cliente comunica — spesso con settimane di ritardo e senza preavviso —
che ha chiuso la posizione internamente o con un altro canale, mentre Katia aveva già
investito tempo nei colloqui e denaro in tool e job post.

È una delle situazioni più dannose economicamente e più difficili da gestire emotivamente,
perché non c'è rimborso contrattuale e la rabbia non aiuta a recuperare il rapporto.

### 7.1 Obiettivi della risposta

- **Tenere la porta aperta** per le posizioni ancora in ballo o future
- **Riposizionarsi proattivamente** proponendo uno switch su altre posizioni aperte
- **Far percepire il valore del contesto acquisito** — conosce già il team, il prodotto,
  il modo di lavorare: questo vale e accelera qualsiasi ricerca futura
- **Non bruciare il rapporto** anche se la frustrazione è legittima

### 7.2 Cosa NON fare

- Non sparire in silenzio — sembra un rifiuto passivo e chiude la porta
- Non esprimere frustrazione apertamente — anche se giustificata, non recupera nulla
- Non chiedere spiegazioni sul perché — mette il cliente sulla difensiva
- Non fare pressione per un compenso se non è previsto contrattualmente

### 7.3 Formula di risposta — porta aperta + switch

Tono: caldo, diretto, senza vittimismo. Il messaggio deve trasmettere professionalità
e orientamento alla soluzione, non delusione.

**Versione diretta (WhatsApp/messaggio):**
"Ciao [Nome], grazie per l'aggiornamento — capisco, succede!
Detto questo, ho investito tempo e risorse su questa ricerca, quindi se avete altre
posizioni aperte mi farebbe piacere continuare a collaborare lì — conosco già il contesto
e il team, il che mi permette di partire avvantaggiata.
Hai qualcosa su cui posso esserti utile?"

**Versione professionale:**
"Grazie per avermi aggiornata. Compreso il contesto. Se avete altre posizioni aperte
o in apertura, sono disponibile a valutare — ho già il vostro background e capire come
lavorate mi permette di essere più efficace fin da subito. Fammi sapere."

### 7.4 Il selling point dello switch

Il vantaggio reale da far pesare (senza dirlo esplicitamente):
- Conosce già la cultura aziendale, il team, il modo di dare feedback
- Sa già cosa funziona e cosa no per quel cliente specifico
- Non ha bisogno del kick-off — può partire quasi subito
- I candidati già screened potrebbero essere riutilizzabili per altre posizioni

Questo vale economicamente e in termini di velocità — è un argomento concreto,
non una concessione sentimentale.

### 7.5 Prevenire la situazione nel futuro

- Inserire nel contratto di ricerca una clausola di rimborso spese (o fee ridotta)
  in caso di chiusura anticipata della posizione dopo X colloqui effettuati
- Fare check-in proattivi con il cliente ogni 2-3 settimane per capire se ci sono
  sviluppi interni prima che diventino decisioni già prese
- Al kick-off chiedere esplicitamente: "Avete posizioni simili aperte o in apertura
  nei prossimi mesi?" — così si mappano le opportunità di switch fin dall'inizio

---

## 8. GESTIONE DEL NO DEL CANDIDATO (dopo l'offerta)

Se il candidato rifiuta:
1. Capire il motivo reale (spesso non è quello dichiarato)
2. Valutare se il motivo è risolvibile → proporre al cliente se ne vale la pena
3. Se non è risolvibile: accettare il no con professionalità
4. Mantenere la relazione: "Capisco. Se in futuro cambiasse qualcosa, mi farebbe piacere restare in contatto."
5. Un no oggi può diventare un sì tra 12 mesi — o un referral domani.

**Mai bruciare un candidato** anche se ha rifiutato dopo un iter lungo.
Il mercato IT Milano è piccolo. Le persone si conoscono.

---

## 8. NEGOZIAZIONE AVANZATA — TEORIA E TECNICA

### 8.1 I profili negoziali della controparte

Riconoscere con chi si ha a che fare prima di scegliere la strategia.

**Accomodante**
Evita il conflitto a tutti i costi. Si ritira piuttosto che parlare chiaramente.
Tiene le carte in mano. Non dirà mai apertamente cosa vuole.
→ Strategia: creare uno spazio sicuro, fare domande aperte, non pressare.
"Ho la sensazione che ci sia qualcosa che non ha ancora detto — sono qui per capire."

**Pragmatico (win-win)**
Cerca soluzioni condivise. Parla di interessi, non di posizioni.
Flessibile, ascolta, condivide informazioni. Usa "noi" invece di "io/tu".
→ Strategia: corrispondere lo stesso registro. Collaborare apertamente.

**Pressante (win-lose)**
Si fa di tutto per sottolineare i vantaggi propri e la forza.
Diretto, quasi minacciante. Tende a personalizzare e arrabbiarsi.
Tira fuori una questione alla volta. Soluzioni rigide.
→ Strategia: non reagire alla pressione. Mantenere calma. Non rispondere agli attacchi.
Usare empatia e domande. Spostare verso il win-win.

**Persuasivo (pressante)**
Spende molte parole per spiegare le sue posizioni.
Tende a offendersi se le proposte non corrispondono alle sue attese.
→ Strategia: ascoltare, riconoscere le emozioni, non cedere su sostanza per quieto vivere.

---

### 8.2 Segnali di negoziazione win-lose da riconoscere

La controparte usa una strategia win-lose quando:
- Proposta iniziale "estrema" (fuori mercato, irrealistica)
- Rimane sulle posizioni, non sugli interessi
- Usa "io, me, tu" — non "noi"
- Sottolinea le distanze, non i punti comuni
- Fa riferimento a passate insoddisfazioni
- Tira fuori una questione alla volta (tattica del salame)
- Soluzioni rigide: bianco-nero, prendere o lasciare
- Parla molto, non ascolta, non condivide informazioni
- Postura rigida, tono assertivo o aggressivo

**Come spostare win-lose verso win-win:**
1. Non reagire alla pressione — pausa consapevole
2. Non rispondere agli attacchi — empatia invece di difesa
3. Mantenere calma, tono basso, espressione tranquilla
4. Fare molte domande su pareri, motivazioni, timori
5. Sintetizzare e riformulare in chiave comune
6. Manifestare disagio senza note emotive
7. Dichiarare di riconoscere il trucco (solo se necessario)

---

### 8.3 Gli sgambetti negoziali — come riconoscerli e rispondere

Tattiche che la controparte usa (candidato o cliente) e come gestirle:

**"Il confronto misterioso"** — "Abbiamo un'altra offerta migliore"
→ Non cedere automaticamente. "Posso chiederle quali sono i termini? Voglio capire
se c'è margine per allinearci o se siamo su piani diversi."

**"I vincitori esterni"** — "Il mercato non paga più di X"
→ Portare dati reali. "In base ai benchmark per questo stack a Milano, il range è Y-Z.
Posso mostrarle le fonti."

**"La roulette russa"** — "Se non facciamo così, non possiamo andare avanti"
→ Valutare se è un bluff. Se non si è pronti a lasciare andare, non usare la stessa
tattica di ritorno. Spostare su interessi: "Capisco l'urgenza. Vediamo cosa possiamo fare."

**"L'anticipazione della conclusione"** — "Ok, facciamo X€ e chiudiamo"
→ Non lasciarsi trascinare dalla fretta. "Apprezzo la voglia di chiudere. Fammi verificare
che questa cifra copra effettivamente le aspettative del candidato."

**"La scadenza artificiale"** — "Dobbiamo decidere entro domani"
→ Verificare se è reale. "Capisco l'urgenza. Cosa cambia se prendiamo 48h in più?"
Se la scadenza è vera: accelerare. Se è una tattica: non farsi condizionare.

**"Mancanza di autorità"** — "Devo ancora chiedere al mio capo / ufficio legale"
Usata spesso DOPO che si è quasi concluso, per riaprire la negoziazione.
→ "Capisco. Quando possiamo avere una risposta definitiva? Nel frattempo confermo
che i termini che abbiamo concordato restano validi da parte nostra."

**Piccole concessioni dopo la conclusione** — "Si potrebbe aggiungere anche..."
Ogni volta che si concorda qualcosa, viene fatta una piccola obiezione aggiuntiva.
→ Non cedere, anche su piccole cose. Ogni concessione finale indebolisce la posizione.
"Abbiamo già definito i termini. Possiamo riaprire la discussione solo se ci sono
cambiamenti sostanziali su entrambi i lati."

---

### 8.4 Tecniche di negoziazione che funzionano

**Chi domanda comanda.** Le domande danno controllo senza creare resistenza.
Usare sempre più domande che affermazioni nelle fasi critiche.

**Mirroring.** Ripetere le ultime 2-3 parole della controparte e fare una pausa.
Crea connessione e spinge l'altro a elaborare il proprio pensiero.
Candidato: "Non sono sicuro dei benefit..." → Katia: "Non sei sicuro dei benefit?"
→ Il candidato elabora, spesso rivela la vera obiezione.

**Etichettare le emozioni.** "Sembra che lei sia preoccupato per i tempi..."
La controparte si sente compresa. La tensione scende. Si apre lo spazio per i fatti.

**Non usare cifre tonde.** €75.000 sembra ragionato. €75.000 esatti sembrano arbitrari.
Usare cifre specifiche per dare l'impressione di un'analisi accurata.

**Non chiedere "perché".** Viene percepito come un'accusa.
Sostituire con "cosa l'ha portata a questa conclusione?" o "aiutami a capire..."

**Cercare "è giusto", non "hai ragione".** La controparte vuole essere compresa,
non sconfitta. "È giusto" segnala comprensione senza cedimento.

**Il potere del "no".** Cercare di far sempre dire sì alla controparte è un errore —
si sentirà in trappola. Lasciare spazio per un no: "Sarebbe sbagliato pensare che...?"
Il "no" apre la negoziazione — può significare "non sono pronto", "non capisco",
"ho bisogno di più informazioni", "voglio qualcos'altro".

**La proposta iniziale deve essere superiore all'obiettivo**, ma non oltre la MAP
(Migliore Alternativa Possibile) della controparte. Deve essere articolata e spiegata,
non solo un numero. Comunicata in modo fermo, senza titubanze.

**Cosa NON dire mai:**
- "Ci penserei un momentino..."
- "Beh... pensavo fosse qualcosa tra X e Y"
- "Mi rendo conto che potrebbe sembrare strano, ma..."
Queste formule segnalano insicurezza e indeboliscono la posizione.

---

### 8.5 Tecniche di chiusura

Quando si è vicini all'accordo, non lasciare che la negoziazione si riapra.

- **Riassunto della situazione:** riepilogare tutto ciò su cui si è d'accordo prima di chiedere la firma
- **Ultima piccola concessione inattesa:** sorprende positivamente e crea il momento giusto
- **Scelta tra alternative marginali:** "Preferisce iniziare il 1° o il 15 del mese?"
  (entrambe le opzioni implicano che si inizia — la domanda è solo sul quando)
- **Illustrazione della fase successiva:** "Se siamo d'accordo, il passo successivo è..."
  Portare mentalmente la controparte al "dopo" la firma

**Da evitare:**
"Ultima offerta, prendere o lasciare" — usare solo se si è pronti davvero ad abbandonare.
Se si fa marcia indietro, si perde credibilità permanentemente.

---

### 8.6 Separare le persone dal problema

Principio fondamentale: essere flessibili con le persone, fermi sugli obiettivi.

**Percezioni:** affrontare i pregiudizi della controparte su Katia o sulla proposta.
Evitare deduzioni, attenersi ai fatti. Far partecipare la controparte alla soluzione.

**Stati d'animo:** non attaccare le persone. Riconoscere le emozioni reciproche.
Non reagire mentre la tensione è alta. Consentire alla controparte di sfogarsi.
"Capisco che questa situazione sia frustrante. Parliamo di quello che ci divide."

**Comunicazione:** curare il linguaggio del corpo. Essere chiari e concreti.
Raccontare cosa si può fare, non cosa non si può. Elencare gli interessi comuni.
Ascoltare attentamente, verificare di frequente.

---

### 8.7 Domande di debriefing post-negoziazione

Dopo ogni negoziazione complessa, riflettere su:
- Ho chiuso come desideravo? Se no, perché?
- Sono riuscita a seguire la strategia che avevo preparato?
- Se ricominciassi, cosa farei diversamente?
- Entrambe le parti hanno ottenuto vantaggi?
- Quando siamo stati in difficoltà e come ho reagito?
- È stata win-win o win-lose?
- Sono stati usati sgambetti negoziali? Li ho riconosciuti?
- Come posso migliorare la comunicazione nella fase di apertura?
