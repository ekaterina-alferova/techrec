---
name: recruiter-candidate
description: >
  Usa questa skill ogni volta che lavori con un candidato:
  Use this skill whenever you work with a candidate: analisi CV, preparazione
  domande pre-colloquio, conduzione colloquio (motivazionale + tecnico-contrattuale),
  produzione scorecard post-colloquio, gestione feedback durante l'iter, fase pre-offerta
  e gestione JO. Trigger: "analizza questo cv", "prepara le domande per il colloquio",
  "fai la scorecard", "ho fatto il colloquio con X", "il cliente sta per mandare la lettera",
  "come gestisco la controfferta", "candidato tentenna", "feedback negativo generico",
  "presenta il candidato al cliente". Usala anche se incolli un transcript di colloquio
  grezzo o vuoi valutare un profilo rispetto a una posizione aperta.
  "present the candidate to the client". Also triggers when you paste a raw interview transcript
  or want to evaluate a profile against an open position.
---

# Recruiter Candidate — Framework

Il recruiter gestisce l'intero ciclo del candidato con approccio analitico e consulenziale.
I candidati IT sono prevalentemente passivi (90%+). La reattività è un must —
un candidato disponibile va presentato ASAP prima che un'altra agenzia faccia JO.

---

## FASE 1 — ANALISI CV E TRIAGE

### 1.1 Screening CV rispetto al kick-off
Leggere il CV attraverso la lente del transcript di kick-off (must have / NTH / red flag).

Produrre una valutazione rapida strutturata in:
- **Tier 1** — contattare subito (match alto su must have)
- **Tier 2** — stand-by (match parziale, valutare in base alla pipeline)
- **KO** — fuori scope (con motivazione esplicita)

Per ogni CV Tier 1, evidenziare:
- Punti di forza rispetto al ruolo (con evidenze dal CV, non opinioni generiche)
- Gap potenziali da esplorare in colloquio
- Domande specifiche da fare basate sul percorso
- Segnali di instabilità o pattern da chiarire (job hopping, periodi non spiegati, ecc.)

### 1.2 Outreach LinkedIn (300 caratteri max)
Formato: diretto, tech-friendly, con link al proprio profilo o pagina di prenotazione call
- Menzionare il ruolo e l'azienda se non confidenziale
- Non usare formule generiche ("opportunità interessante", "realtà in forte crescita")
- Tono peer-to-peer, non corporate
- Includere il link per prenotare call (usare placeholder [LINK_CALENDAR])

Messaggio WhatsApp per candidature dirette:
Più caldo, personalizzato, con link calendar.
Modello: "Ciao [Nome], sono [Nome Recruiter] - ti scrivo in merito alla tua candidatura per [ruolo].
Mi piacerebbe schedulare una chiacchierata per darti visibilità a 360° sia dell'azienda/ruolo,
sia del prodotto. Ti allego un link per prenotare una call [LINK]. Qualora non dovessi
trovare uno slot che ti torna bene, fammi sapere."

---

## FASE 2 — COLLOQUIO CON IL CANDIDATO

Il colloquio ha tre blocchi distinti. L'ordine consigliato: contrattuale → tecnico → motivazionale.
La parte motivazionale è la più critica e va esplorata in profondità — un candidato
portato sotto-offerta o non motivato è un epic fail.

### 2.1 Blocco contrattuale
**Inquadramento attuale:**
- CCNL (se non metalmeccanico/commercio: verificare quante mensilità)
- Livello contrattuale
- RAL attuale (se dipendente) o ultima cifra dichiarata (se P.IVA)
- RAL desiderata (sempre chiedere, anche se c'è un range del cliente)

**Compensation package completo:**
- Bonus: MBO, premio aziendale, di produzione — importo e quando erogato
- Stock option: verificare formulazione su liquidity event
  - "L'azienda si obbliga a comprare" = soldi garantiti
  - "L'azienda può comprare" = non garantito
  - Se LE è in programma a breve: probabilità bassa di cash
- Buoni pasto (importo)
- Auto aziendale: uso promiscuo / fuel card / rimborso km
- Assicurazione integrativa
- Welfare
- Strumenti di lavoro

**Logistica:**
- Notice period e se è trattabile
- Modalità attuale (full remote, ibrido, on-site)
- Se il ruolo prevede presenza: disponibilità a valutare ibrido
- Altri iter in corso (fase e RAL in gioco)

**Nota:** A breve la normativa italiana limiterà le domande sulla RAL attuale.
Chiedere solo la desiderata e la situazione attuale in modo indiretto se necessario.

### 2.2 Blocco tecnico (stack & progetti)
Non serve sapere tutto — far parlare il candidato è la regola d'oro.

- Progetto attuale: di cosa si tratta, stack usato, ruolo specifico
- Progetto più sfidante o soddisfacente della carriera (capire il perché)
- Stack preferito e perché
- Se full stack: preferenza BE o FE? Percentuale attuale?
- Per ruoli di leadership: come ha gestito situazioni difficili (persone, conflitti, PIP)
- Per ruoli senior: scelte architetturali significative che ha fatto/influenzato

### 2.3 Blocco motivazionale (il più importante)

**Tre domande fondamentali prima di tutto:**
1. Perché sta valutando il mercato / la nostra offerta in questo momento?
2. Ha altri iter in corso? In che fase? Quando attende feedback?
3. Se il suo attuale datore facesse una controfferta a parità economica, cosa valuterebbe?

**Blocco 1 — Ruolo attuale:**
- Cosa lo ha spinto a scegliere questo ruolo (motivazione all'ingresso)
- È soddisfatto di quella scelta? Tornasse indietro, rimarrebbe?
- Sviluppi previsti in azienda
- Ha raggiunto gli obiettivi che si era posto?
- C'è possibilità di crescita nel ruolo attuale?
- Cosa vorrebbe fare di più / di meno rispetto ad oggi?

**Blocco 2 — Sviluppi interni:**
- Ha parlato delle opportunità interne con il suo responsabile?
- Cosa potrebbe farlo restare altri 5 anni in azienda?
- Se insoddisfatto: ha provato a crescere internamente prima di guardare fuori?
  (Attenzione: se non l'ha fatto, rischio controfferta alto)

**Blocco 3 — Tempistiche:**
- Considerando il preavviso, quando potrebbe iniziare idealmente?
- Performance review in arrivo?
- Aumento previsto quest'anno?
- Benefit in scadenza o in attesa?

**Domanda ambiente vs RAL (rivelatore del mercenario):**
"Preferirebbe un ambiente di lavoro un po' tossico con RAL altissima, o un ambiente molto
positivo con RAL più bassa? Perché?" — La risposta rivela la priorità reale.

---

## FASE 3 — SCORECARD POST-COLLOQUIO

La scorecard è il documento che va al cliente. Non è un riassunto neutro —
è una valutazione consulenziale. Il recruiter ci mette la faccia.

### 3.1 Struttura scorecard

**Intestazione:** Nome candidato | Azienda | Ruolo

**Sezione Pre-Screening** (tabella):
Per ogni criterio del kick-off (must have + must logistici):
- Criterio
- Esito: 🟢 Forte / 🟢 Presente / 🟡 Da verificare / 🔴 KO
- Risposta/Evidenza (concreta, non generica — citare quello che ha detto)
- Note consulenziali (interpretazione, contesto, cosa significa per il cliente)

Criteri standard da includere sempre:
- Anni e tipo di esperienza rilevante
- Must have tecnici (max 3, come da kick-off)
- Fit con tipo di azienda (startup/scale-up/corporate/consulenza)
- Disponibilità logistica (sede, giorni, relocation se prevista)
- Notice period
- RAL desiderata vs budget cliente

**Note operative** (blocco testo):
Sintesi degli elementi pratici chiave — inquadramento, tempistiche, situazione attuale.
Scritto in modo che il cliente possa prendere una decisione senza rileggere tutto.

**Valutazione Sintetica** (tabella):
Per ogni area rilevante al ruolo (4-6 aree):
- Area
- Valutazione (emoji semaforo)
- Evidenze oggettive (cosa ha detto/fatto — verificabile)
- Valutazione consulenziale (interpretazione del recruiter — aggiunge valore al dato grezzo)

Aree tipiche per ruoli tech:
- Competenza tecnica / stack
- Seniority ed autonomia
- Fit con il contesto aziendale
- Leadership / people management (se rilevante)
- Stabilità e commitment
- Motivazione al cambio

**Executive Assessment:**
- Overall fit stimato (%)
- Paragrafo narrativo: perché questo candidato è (o non è) adatto a questa posizione specifica.
  Non minimizzare i punti di caduta — mitigarli sì, nasconderli mai.
  Spingere sulle evidenze positive con ragionamento consulenziale.

**Hiring Risk Matrix** (tabella):
- Area di rischio
- Livello (🔴/🟡)
- Probabilità
- Impatto
- Evidenze
- Strategia di mitigazione

### 3.2 Principi redazionali della scorecard
- Evidenze concrete > opinioni generiche ("Ha gestito PIP documentato con HR" non "buono con le persone")
- La valutazione consulenziale aggiunge interpretazione al dato — non ripete il dato
- I punti di caduta vanno nominati, non eufemizzati — e va proposta una strategia
- Se un criterio è "da verificare", indicare esattamente cosa va verificato e da chi
- Tono autorevole ma non assertivo su ciò che è incerto

---

## FASE 4 — GESTIONE ITER E FEEDBACK

### 4.1 Touchpoint durante l'iter
- Prima call di sourcing
- Videocall/colloquio principale
- Dopo presentazione al cliente: chiamata con feedback (positivo o negativo)
- Dopo ogni step con il cliente: raccogliere feedback da candidato E da cliente

Domande post-step:
- Com'è andata dal suo punto di vista?
- C'è qualcosa che l'ha sorpresa o che non si aspettava?
- Nel frattempo ha sviluppi su altri fronti?
- Ha ricevuto altre JO?

### 4.2 Gestione feedback negativo dal cliente
Se il feedback è generico ("non ci ha convinto"), il recruiter lo ricostruisce
in base ai punti di caduta emersi durante i suoi colloqui.
Non inventare — interpretare con coerenza rispetto ai dati raccolti.

---

## FASE 5 — PRE-OFFERTA E GESTIONE JO

Quando il cliente anticipa che sta formulando l'offerta: non è il momento di rilassarsi.

### 5.1 Call pre-offerta con il candidato
- Dare feedback positivo (senza garantire JO)
- "Stanno valutando altri profili, ma ho un buon presentimento"
- "A valle di tutti i passaggi, quale offerta riterresti onesta per accettare?"
  Se esita: c'è qualcosa che non va — esplorare.
- "Scordiamo per un momento la RAL — è un lavoro che vorrebbe? Se no, fermiamoci qui."
- Se tentenna: "Ho la sensazione che non sia del tutto sicuro. Dopo l'impegno che ha messo,
  sono un po' sorpresa. Potrebbe condividere i dubbi con me?"

### 5.2 Scala di interesse 1-10
Chiedere al candidato di dare un punteggio rispetto alle altre opportunità/al ruolo attuale:
- 10 = super-interessante a breve e lungo termine
- 8-9 = opportunità che interessa seriamente
- 6-7 = possibilità remota

Se abbiamo lavorato bene: la risposta sarà 8-9.
Domanda seguente: "Cosa dovrebbe avere questa JO per arrivare a 10?"

### 5.3 Analisi comparativa delle offerte (JO multipli)
Dividere ogni offerta in tre fasce di probabilità:

**90% probabilità** (quasi certo):
RAL, buoni pasto, welfare, ass. integrativa, bonus produzione, entry bonus, bonus fedeltà,
patto di non concorrenza. (Non 100% perché: periodo di prova, rischio aziendale, ecc.)

**50% probabilità:**
MBO, premio di risultato — dipende da performance, KPI, dinamiche aziendali.
Chiedere al cliente: media storica dei bonus per ruoli simili + come vengono definiti i KPI.

**5% probabilità:**
Stock option (dipende da liquidity event), bonus overperformance, aumenti futuri.

Presentare confronto in tabella: JO A vs JO B per ogni fascia.
L'obiettivo è aiutare il candidato a fare una scelta informata, non a convincerlo.

### 5.4 Gestione controfferta
"Se il cliente arriva o supera la controfferta, può garantirmi la firma? Sì o no?
Devo essere sicura prima di mettere la faccia pure io."

La lettera d'impegno esce solo quando:
- Il candidato ha verbalmente accettato
- Tutti i dubbi sono stati smarcelati
- Il punteggio è 9-10
- Non ci sono altri iter in fase avanzata non gestiti

---

## RIFERIMENTI E COLLEGAMENTO CON ALTRE SKILL

**Collegamento con `recruiter-kickoff`:**
La scorecard si costruisce SEMPRE a partire dal transcript del kick-off con il cliente.
Il flusso corretto è:
1. Transcript kick-off → estrae i criteri (must have, nice to have, red flag, logistica, compensazione)
2. CV del candidato → triage Tier 1/2/KO rispetto ai criteri del kick-off
3. Transcript del colloquio con il candidato → compila le evidenze per ogni criterio
4. Scorecard finale → sintesi dei tre input con valutazione consulenziale

Se manca il transcript del kick-off: chiedere di fornirlo o ricostruirlo
dalle note disponibili prima di procedere con la scorecard.

**Leggere quando rilevante:**

- `references/feedback-comunicazioni.md` — Gestione completa di feedback e comunicazioni
  delicate: feedback positivo e negativo al cliente (con e senza evidenze), come comunicare
  la situazione del mercato (RAL bassa, bacino ristretto, reputazione negativa del cliente),
  come comunicare il ritiro del candidato e il rifiuto dell'offerta, come costruire un feedback
  KO plausibile senza evidenze dal cliente, come gestire il candidato che tentenna
  (unica speranza di placement) senza trasmettere urgenza. Include script pronti e tabella
  riepilogativa tono/approccio per ogni situazione.
  Usare per: qualsiasi comunicazione delicata verso cliente o candidato.

- `references/imprevisti-negoziazione.md` — Ghosting candidati e clienti (segnali predittivi
  e protocolli di recupero), obiezioni del cliente (età, RAL, feedback generico), negoziazione
  RAL con cliente e candidato, psicologia del candidato (motivazioni nascoste, punteggio 1-10,
  tecniche per spingere verso la firma), gestione no post-offerta. **Sezione 8 — Negoziazione
  avanzata:** profili negoziali della controparte (accomodante/pragmatico/pressante), segnali
  win-lose, sgambetti negoziali e come rispondere (confronto misterioso, scadenza artificiale,
  mancanza di autorità, piccole concessioni post-accordo), tecniche che funzionano (mirroring,
  etichettare le emozioni, il potere del no, chiusura), separare persone dal problema.
  Usare per: qualsiasi situazione di stallo, obiezione, o dinamica inaspettata durante l'iter.

## NOTE DI STILE

- Output in italiano salvo diversa indicazione
- Scorecard: tono autorevole, struttura tabellare + prosa per assessment e risk matrix
- Feedback candidato: caldo ma professionale, mai generico
- Messaggi outreach: diretti, brevi, tech-friendly
