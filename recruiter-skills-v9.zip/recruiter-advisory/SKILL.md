---
name: recruiter-advisory
description: >
  Usa questa skill quando lavori nella tua veste di advisor/fractional COO per agenzie
  di recruitment. / Use this skill when working as advisor/fractional COO for recruitment agencies. Trigger: "advisory", "diagnosi agenzia",
  "processo dell'agenzia", "CRM", "valutare i recruiter", "framework valutazione recruiter",
  "come strutturiamo il processo", "roadmap agenzia", "deliverable advisory", "retainer",
  "proposta advisory", "implementazione processo", "scorecard recruiter", "KPI agenzia".
  Usala anche se stai lavorando all'analisi operativa di un'agenzia, feedback ai partner,
  o vuole strutturare un output consulenziale per un cliente agenzia.
---

# Recruiter Advisory — Framework

Il recruiter/advisor opera come fractional COO per agenzie di recruitment IT.
Il posizionamento: porta metodologia e sistemi da recruiter senior sul campo,
non best practice teoriche. Lavora in affiancamento, non per delega.

---

## CONTESTO TIPICO DI INGAGGIO

Il cliente tipo è un'agenzia di recruitment IT con 2-5 partner fondatori che:
- Ha volumi crescenti ma processi non strutturati
- Ha recruiter interni da valutare / formare / standardizzare
- Sta implementando o ha già un ATS/CRM da ottimizzare
- Vuole differenziarsi nel mercato come agenzia di qualità (non solo volume)
- Ha già collaborato con il recruiter/advisor e vuole ora un rapporto più strutturato

Modello di engagement tipico: retainer mensile a 3 fasi con deliverable definiti.

---

## FASE 1 — DIAGNOSI INIZIALE

Prima di proporre qualsiasi soluzione, capire lo stato reale dell'agenzia.

### 1.1 Intervista diagnostica ai partner
Domande chiave:
- Come è strutturato oggi il processo end-to-end (dal mandato alla chiusura)?
- Chi fa cosa? Ci sono sovrapposizioni o gap di responsabilità?
- Quali KPI tracciate? (Placement rate, time-to-hire, conversion rate per step)
- Come valutate le performance dei recruiter? Esiste un framework o è tutto intuitivo?
- Quali tool usate? Come è configurato il CRM/ATS? Come viene effettivamente usato?
- Quali sono i mandati che non riuscite a chiudere? Perché?
- Dove si perdono i candidati nel funnel?
- Come si posizionate rispetto ai competitor? Cosa vi differenzia (o dovrebbe)?
- Qual è il profilo dei recruiter interni? Seniority, specializzazioni, punti di forza e debolezza?

### 1.2 Audit del processo esistente
Raccogliere e analizzare (se disponibili):
- Template di presentazione candidati verso il cliente
- Esempio di scorecard o brief interno
- Template kick-off o brief ricevuto dai clienti
- Pipeline CRM: come è strutturata, come viene usata, cosa viene tracciato
- Metriche storiche (se esistono)

### 1.3 Output diagnostica
Documento strutturato con:
- Mappa del processo attuale (as-is) con gap evidenziati
- Top 3 problemi prioritari da risolvere
- Opportunità quick win (impatto alto, sforzo basso)
- Rischi operativi in corso
- Raccomandazioni per le fasi successive

---

## FASE 2 — FRAMEWORK VALUTAZIONE RECRUITER

L'advisor valuta i recruiter interni dell'agenzia con un approccio strutturato,
non basato sull'impressione ma su evidenze osservabili.

### 2.1 Dimensioni di valutazione

**Qualità del sourcing:**
- Sa leggere un profilo LinkedIn in modo critico prima di contattarlo?
- Le booleane che costruisce sono pertinenti e creative?
- Il tasso di risposta all'outreach è nella media o sotto?
- Sa distinguere Tier 1 / Tier 2 / KO velocemente?

**Qualità del kick-off con il cliente:**
- Raccoglie tutte le informazioni necessarie o lascia gap?
- Sa fare domande challenger o accetta passivamente il brief?
- Sa riconoscere un profilo irrealistico e lo dice al cliente?
- Prepara la call con ricerca sull'azienda o arriva a mani vuote?

**Qualità del colloquio con il candidato:**
- Esplora in profondità la motivazione o si ferma alla superficie?
- Sa distinguere tra candidato motivato e mercenario?
- Gestisce il blocco contrattuale con accuratezza (compensation package completo)?
- Sa leggere i segnali di rischio controfferta?

**Qualità della scorecard:**
- Evidenze concrete vs opinioni generiche?
- I punti di caduta sono nominati o nascosti?
- La valutazione consulenziale aggiunge interpretazione o ripete il dato?
- Il cliente può prendere una decisione leggendo solo la scorecard?

**Gestione dell'iter:**
- Mantiene il ritmo dei touchpoint con candidato e cliente?
- Raccoglie feedback specifici o si accontenta di "ci fa sapere"?
- Sa gestire la fase pre-JO senza perdere il candidato?
- Anticipa i problemi o li gestisce a scoppio?

**Business acumen:**
- Capisce il mercato IT abbastanza da non fare figuracce con i candidati tech?
- Sa quantificare l'offerta economica in modo comparativo?
- Ha un approccio da consulente o da esecutore?

### 2.2 Scala di valutazione
Per ogni dimensione: 1-4
- 4 = Eccellente, fa da benchmark interno
- 3 = Solido, gestisce autonomamente
- 2 = In sviluppo, necessita supervisione su questa area
- 1 = Gap significativo, richiede formazione/affiancamento

### 2.3 Output valutazione recruiter
Per ogni recruiter: scheda individuale con:
- Valutazione per dimensione (tabella)
- Narrative assessment (punti di forza reali + aree di sviluppo prioritarie)
- Raccomandazioni (formazione, affiancamento, riposizionamento)
- Piano di sviluppo a 90 giorni

---

## FASE 3 — IMPLEMENTAZIONE PROCESSI

### 3.1 Standardizzazione del processo end-to-end
Produrre e implementare:
- Template kick-off standard (adattabile per profilo/ruolo)
- Struttura scorecard standard dell'agenzia
- Checklist qualità prima di presentare un candidato al cliente
- Framework per analisi comparativa offerte (JO multipli)
- Protocollo touchpoint durante l'iter (quando chiamare, cosa chiedere)
- Template feedback candidato (positivo/negativo)

### 3.2 CRM / ATS
- Audit dell'utilizzo attuale (cosa viene tracciato vs cosa dovrebbe essere tracciato)
- Definizione pipeline stage con criteri chiari di avanzamento
- Campi obbligatori per ogni stage
- KPI da estrarre dal CRM per monitorare le performance
- Formazione team sull'utilizzo standardizzato

### 3.3 KPI agenzia
Dashboard minima consigliata:
- Placement rate (mandati chiusi / mandati aperti nel periodo)
- Time-to-hire medio per tipologia di ruolo
- Conversion rate per step del processo di selezione
- Tasso di drop candidati (e in quale step)
- Tasso di controfferta / JO rifiutate
- Revenue per recruiter
- Mandati per fonte (inbound, referral, outbound)

### 3.4 Posizionamento e differenziazione
- Analisi del posizionamento attuale vs desiderato
- Identificazione del niche di specializzazione (se non già definito)
- Review del materiale verso i clienti (proposta commerciale, presentazione agenzia)
- Raccomandazioni su pricing e struttura del fee

---

## STRUTTURA DELIVERABLE ADVISORY

Ogni engagement produce deliverable tangibili per fase.
I documenti vengono firmati con il nome dell'advisor o con brand agenzia se richiesto.

**Fine Fase 1 (Diagnostica):**
- Report diagnosi as-is (PDF o doc condiviso)
- Roadmap proposta per Fase 2 e 3

**Fine Fase 2 (Valutazione recruiter):**
- Schede individuali per recruiter
- Report aggregato per la partnership/management
- Piano di sviluppo team

**Fine Fase 3 (Implementazione):**
- Template operativi finalizzati
- Configurazione CRM documentata
- Dashboard KPI attiva
- Handbook del processo (documento di riferimento per il team)

---

## PRINCIPI ADVISORY

- L'advisor non porta framework teorici da manuale — porta ciò che
  ha verificato funzionare nel mercato IT nella propria pratica diretta.
- Non esegue il lavoro operativo dei recruiter — progetta i sistemi e forma chi li usa.
- I deliverable hanno sempre una componente scritta e una componente di affiancamento.
- Le raccomandazioni scomode vanno dette ai partner chiaramente, anche se riguardano
  persone del team o scelte che hanno già fatto.
- Il successo dell'advisory si misura su dati: placement rate, time-to-hire, qualità
  percepita dai clienti — non su quanto i partner si sono sentiti "supportati".

---

## NOTE DI STILE

- Output in italiano salvo diversa indicazione
- Documenti verso l'agenzia cliente: tono professionale, struttura chiara, linguaggio diretto
- Report interni: non edulcorare i problemi — la diagnosi onesta è il valore principale
- Evitare il jargon consulenziale vuoto ("ecosistema", "sinergie", "ottimizzare le best practice")
