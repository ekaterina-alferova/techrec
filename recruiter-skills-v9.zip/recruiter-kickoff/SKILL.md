---
name: recruiter-kickoff
description: >
  Usa questa skill ogni volta che devi prepararti a un kick-off con un cliente,
  condurre la call, o rielaborare il transcript dopo.
  Use this skill whenever you need to prepare for a client kick-off,
  run the call, or process the transcript afterwards. Trigger: "kick-off", "preparo la call
  col cliente", "ho fatto il kick-off", "devo capire il ruolo", "analisi dell'azienda prima
  della call", "devo mandare la JD", "riscrivi la job description". La skill copre tre momenti:
  (1) ricerca pre-call sull'azienda, (2) conduzione challenger del kick-off, (3) rielaborazione
  post-call in JD + scorecard draft. Usala anche se scrivi "aiutami a capire questo ruolo"
  o incolla un transcript grezzo.
---

# Recruiter Kick-Off — Framework

Il recruiter opera con approccio senior e consulenziale, specializzato nel mercato IT.
Non esegue brief passivamente — li analizza criticamente.
L'approccio è challenger: se il cliente cerca un unicorno, glielo si dice.

---

## MINDSET: IL RECRUITER COME PROJECT MANAGER

Ogni ricerca è un progetto con tre vincoli interdipendenti (il Triangolo del Progetto):
- **Scope** — il profilo richiesto (competenze, seniority, requisiti)
- **Time** — la deadline del cliente
- **Cost** — il budget RAL + il costo del tempo investito

La qualità del placement dipende dall'equilibrio di tutti e tre:
- Velocità + basso costo → la qualità ne risente
- Velocità + alta qualità → servono più risorse
- Alta qualità + basso costo → ci vuole molto più tempo

**Quando il cliente cambia i requisiti (scope creep)**, cambia automaticamente uno o più dei
due rimanenti. Non si può aumentare lo scope senza rinegoziare tempi o costi.

### Obiettivi S.M.A.R.T. per ogni ricerca
Prima di avviare, definire internamente:
- **S**pecifico: quale profilo esatto cerco?
- **M**isurabile: quanti candidati allineati, entro quando?
- **A**ttuabile: ho gli strumenti (LinkedIn, ATS, network, tempo)?
- **R**ilevante: questo obiettivo è realistico per il mercato?
- **T**emporizzabile: deadline chiara (es. "firma entro 6 settimane")

Esempio: "Presentare 3 candidati Senior Java con K8s in produzione entro 2 settimane dal kick-off."

### Approccio Agile alla ricerca
Il recruiting non è waterfall (una shortlist finale consegnata a fine contratto). È agile:
presentare candidati in rolling, raccogliere feedback rapidi, aggiornare i criteri se
il mercato dice che il profilo non esiste.
- Feedback rapidi e frequenti > report formali a fine contratto
- Candidati allineati > quantità di CV inviati
- Collaborazione con il cliente > rigidità del brief iniziale
- Adattarsi al mercato > tenere fermi requisiti irrealistici

### Bisogni vs Requisiti vs Specifiche — la triade del kick-off
Il cliente spesso confonde i tre livelli. Compito del recruiter è allinearli:

| Livello | Caratteristiche | Esempio |
|---|---|---|
| **Bisogno** | Illimitato, soggettivo, spesso implicito. Il "perché" | "Il team è in ritardo sui rilasci" |
| **Requisito** | Specifico, oggettivo, verificabile. Il "cosa" | "PM con exp agile e gestione team cross-functional" |
| **Specifica** | Tecnica, quantificabile, esplicita. Il "come" | "5 anni exp, Jira, full remote, RAL 50K" |

**Attenzione alle aree cieche:**
- Solo bisogno senza specifiche → si procede a intuito, scope creep assicurato
- Requisiti + specifiche senza bisogno → si trova il profilo "perfetto" che non risolve il problema reale
- Solo bisogno + specifiche senza requisiti → si rischia la persona sbagliata per il problema giusto

Il kick-off serve a costruire tutti e tre i livelli in modo coerente.

### MoSCoW — prioritizzare i requisiti
Da fare in due step: prima del kick-off (ipotesi) e aggiornare dopo il primo round di colloqui.

| Priorità | Significato | Comportamento |
|---|---|---|
| **Must** | Imprescindibile. Senza questo il profilo non passa lo screening | Non negoziabile |
| **Should** | Importante ma negoziabile se ci sono tutti i Must | Flessibile |
| **Could** | Nice-to-have solo se non crea problemi su Must e Should | Sacrificabile |
| **Won't** | Fuori scope. Ignorare o rimandare | Non cercare |

Quando il cliente elenca 10 must have: aiutarli a prioritizzare con MoSCoW.
"Se dovesse scegliere i 3 requisiti senza cui non può procedere, quali sarebbero?"

---

## FASE 1 — RICERCA PRE-CALL (prima del kick-off)

Prima di ogni kick-off:

### 1.1 Deep search azienda
Raccogliere e sintetizzare:
- Settore, prodotto/servizio, modello di business
- Stage (startup, scale-up, corporate, consulenza)
- Funding, investitori, round (se startup/scale-up)
- Dimensione team e crescita recente
- Stack tecnologico pubblicamente visibile (GitHub, job ads, LinkedIn, stackshare)
- Cultura e valori dichiarati
- Eventuale reputazione su Glassdoor/LinkedIn
- Notizie recenti (acquisizioni, lanci prodotto, problemi)

### 1.2 Analisi JD originale del cliente (se disponibile)
- Quali requisiti sono realistici vs inflazionati
- Incoerenze (es. "neolaureato con 5 anni di esperienza")
- Tecnologie/ruoli datati o introvabili nel mercato italiano
- Segnali di urgenza o pain reale
- Fascia RAL indicata vs mercato (se non indicata, stimare in base allo stack)

### 1.3 Briefing pre-call
Produrre un documento sintetico con:
- Cosa sappiamo già (non chiedere al cliente ciò che si trova pubblicamente)
- 3-5 ipotesi sul candidato ideale da verificare in call
- Red flag da esplorare
- Domande challenger da preparare

---

## FASE 2 — CONDUZIONE KICK-OFF

Il kick-off è una call consulenziale, non un briefing passivo.
Si entra già informati — si fanno domande per colmare i gap, non per raccogliere l'ovvio.

### 2.1 Struttura della call (ordine flessibile)

**Referente e contesto decisionale**
- Chi è il referente? Chi prende la decisione finale sull'hire?
- Perché nasce questa esigenza ora? (crescita, sostituzione, nuovo progetto)
- Hanno già provato a chiudere internamente? Come è andata?
- Hanno già lavorato con agenzie di ricerca? Esperienza positiva/negativa e perché?
- Hanno già sentito candidati? KO e perché (raccogliere nomi se possibile)

**Compensation & inquadramento**
- CCNL o P.IVA? Se CCNL: quale? Quante mensilità?
- Budget RAL (o fascia) — se esitano, dare una stima e chiedere conferma
- Livello contrattuale
- Bonus: MBO, premio aziendale, produzione — importo e quando viene erogato
- Stock option: formulazione nel contratto su liquidity event (obbligatorio vs "può")
- Buoni pasto (importo)
- Auto aziendale: uso promiscuo, fuel card, rimborso km
- Assicurazione integrativa
- Welfare
- Strumenti di lavoro (PC aziendale, telefono)
- Eventuali benefit aggiuntivi

**Il ruolo**
- Titolo ufficiale e titolo "reale" (spesso divergono)
- Cosa farà nei 30-60-90 giorni (aspettative concrete, non generiche)
- Cosa NON farà (perimetro esplicito — fondamentale per ruoli ibridi o mal definiti)
- A chi riporta
- Eventuali ambizioni di crescita a 1-2 anni

**Il team**
- Team attuale: composizione, seniority, ruoli
- Stack aziendale completo (non solo quello del ruolo)
- Contesto progetto su cui lavorerà
- Eventuali criticità di team (conflitti, sottostaffing, turnover recente)

**Must Have / Nice to Have**
- Massimo 3 must have assoluti (se ne elencano 10, aiutarli a prioritizzare)
- Nice to have realistici
- Titolo di studio e lingua richiesta
- Esperienza minima

**Logistica**
- Sede HQ e presenza richiesta (giorni/settimana)
- Flessibilità oraria
- Trasferte (frequenza, modalità, rimborso)
- Relocation: prevista? Package?
- Visa sponsorship

**Processo di selezione**
- Step previsti e chi è coinvolto in ciascuno
- Presenza di take-home test o live coding (posizione critica: il take-home test non valorizza i senior)
- Time-to-hire medio o deadline
- Format di presentazione candidati atteso (CV + confidential + recap nel corpo mail)

**Sourcing**
- Aziende donor (da cui cercare attivamente)
- Aziende no-touch (da non contattare per outreach)
- Candidati già nel loro radar che non hanno convertito

### 2.2 Domande challenger da inserire dove pertinente
- "Se cercate questa combinazione di skill a questa RAL, il pool in Italia è di circa X persone. Volete che vi mostri come si posiziona il vostro pacchetto rispetto al mercato?"
- "Questo requisito è un hard must-have o è negoziabile se il candidato è forte sul resto?"
- "Avete già provato internamente — cosa non ha funzionato? Voglio evitare di replicare gli stessi errori."
- "Se in 4 settimane non troviamo qualcuno con questi requisiti, cosa siete disposti a flessibilizzare?"

### 2.3 Selling points dell'azienda
Chiedere al cliente i loro 3-5 selling points reali (non quelli da job description).
Cosa li differenzia da competitor? Cosa fa rimanere le persone?

### 2.4 Gestione scope creep durante e dopo il kick-off
Lo scope creep è il cambiamento dei requisiti a ricerca avviata — la causa principale
di inefficienze, costi nascosti e conflitti con il cliente.

**Tipi di scope creep più comuni:**
- Cambio di seniority a metà iter ("in realtà ci serve un senior, non un mid")
- Aggiunta di requisiti non discussi ("ah, dimenticavo, serve anche il tedesco")
- Cambio di sede o modalità di lavoro ("anzi, full on-site")
- Cambio di profilo radicale ("invece del backend, prendiamo un full stack")

**Come rispondere senza dire "no":**
La strategia è riportare il cliente al triangolo del progetto, non opporsi frontalmente.
"Capisco. Se aggiungiamo questo requisito, cambia il perimetro della ricerca —
il pool si restringe e probabilmente i tempi si allungano. Vuole procedere con
questa modifica o preferisce mantenere i criteri originali per rispettare la deadline?"

**Chiedere le priorità:**
"È più importante trovare qualcuno operativo in tempi rapidi, o avere il profilo esatto
anche se ci vogliono altre 4 settimane?"

**Quando il cambiamento è radicale:**
Un cambio di scope sostanziale richiede una rivalutazione commerciale — nuovo accordo,
nuovo brief, reset del timing. Dirlo chiaramente, non assorbirlo in silenzio.

---

## FASE 3 — RIELABORAZIONE POST KICK-OFF

Dopo la call, partendo dal transcript:

### 3.1 Analisi del transcript
- Estrarre e strutturare tutti i dati raccolti
- Identificare gap informativi (cosa non è stato chiarito)
- Segnalare eventuali incoerenze o red flag emerse
- Valutare la realisticità del profilo richiesto vs mercato

### 3.2 Riscrittura JD
Produrre una job description rielaborata che:
- Sia scritta per LinkedIn/pubblico tech (non per il gestionale HR del cliente)
- Apra con il contesto aziendale e il progetto concreto, non con "cerchiamo una risorsa"
- Separi nettamente must have da nice to have
- Includa compensation package (o almeno fascia RAL) se il cliente ha autorizzato
- Includa 3-4 domande di scrematura yes/no per candidature dirette
- Tono diretto, senza buzzword vuote

Struttura JD consigliata:
1. Chi siamo (2-3 righe, sostanza non marketing)
2. Il contesto del ruolo (perché apre ora, su cosa lavorerai)
3. Cosa farai (concreto, con orizzonte 30-60-90 se disponibile)
4. Stack e must have (separati da NTH)
5. Cosa offriamo (package completo o fascia)
6. Come lavoriamo (modalità, sede, processo)
7. Domande di scrematura (max 4, risposta sì/no)

### 3.3 Draft scorecard (passaggio alla Skill 2)
Sulla base dei must have e NTH emersi, preparare la struttura della scorecard
che verrà compilata dopo i colloqui con i candidati.
→ Per la scorecard completa, usare la skill `recruiter-candidate`.

---

## NOTE DI STILE E TONO

- Output in italiano salvo diversa indicazione.
- Preferisce prosa scorrevole e diretta ai bullet point quando possibile.
- Nei documenti verso il cliente: tono professionale ma non formale, mai burocratico.
- Nelle analisi interne: linguaggio diretto, segnalare i problemi senza eufemismi.
- Non minimizzare mai le criticità — meglio dire al cliente una verità scomoda che
  presentare un profilo irrealistico.

---

## RIFERIMENTI

**Leggere quando rilevante durante o dopo il kick-off:**

- `references/time-management.md` — Framework di time management per recruiter in consulenza
  e TA: matrice urgenza/valore (Q1-Q4), pianificazione settimanale, gestione mandati in parallelo,
  time boxing per blocchi di lavoro, gestione fatturazione e pipeline BD, segnali di allarme.
  Usare per: prioritizzare il lavoro su più mandati, pianificare il calendario, decidere se
  accettare un nuovo mandato, sbloccare situazioni di sovraccarico.

- `references/flusso-lavoro.md` — Processo completo dal kick-off al placement in 10 fasi,
  con input richiesti, output prodotti e ruolo di Claude in ogni step. Include checklist
  rapida per fase, timing di riferimento del mercato IT Milano, segnali di allerta e
  regole critiche sulla velocità di risposta. Usare per: capire in quale fase si trova
  una ricerca, sapere cosa produrre dopo, diagnosticare blocchi nel processo.

- `references/stakeholder-map.md` — Matrice stakeholder per recruitment: 7 profili (Sabotatore,
  Oppositore, Sostenitore, Gigante Sopito, Amico, Familiare, Intralcio, Sfidante) con caratteristiche,
  esempi concreti dal mondo recruitment e strategie di gestione. Usare per: capire chi influenza
  il processo prima del kick-off, diagnosticare blocchi durante l'iter, preparare la fase di offerta.

- `references/tech-stack-glossary.md` — Stack IT, sinonimi di ruolo, ruoli equivalenti con ramp-up path,
  aziende target per stack, booleane di sourcing pronte, tabella pool size Milano.
  Usare per: verificare la realisticità del profilo richiesto, identificare profili pivot,
  preparare la strategia di sourcing dal transcript del kick-off.

- `references/compensation-it.md` — Tabella RAL→netto per Metalmeccanico (13 mensilità)
  e Commercio (14 mensilità) da €35k a €150k, costo azienda, preavvisi per CCNL,
  logica P.IVA, stock option (vesting, cliff, liquidity event), auto aziendale + tabelle ACI,
  buoni pasto, welfare, MBO. Usare per: sfidare il budget del cliente nel kick-off,
  fare l'analisi comparativa JO, rispondere alle domande del candidato sul package.

**Collegamento con la skill `recruiter-candidate`:**
Dopo il kick-off, il transcript diventa l'input per due output nella skill candidate:
1. La struttura della scorecard (sezione pre-screening con i criteri del kick-off)
2. Le domande personalizzate per il colloquio (basate su must have + red flag identificati)
Quando si genera la scorecard, richiamare esplicitamente i criteri del kick-off come colonna
"Criterio" della tabella pre-screening.
