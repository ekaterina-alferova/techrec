# Flusso di Lavoro Completo — Dal Kick-Off al Placement

## COME USARE QUESTO FILE
Questo file descrive la sequenza precisa del processo di recruitment di Katia,
con gli input richiesti, gli output prodotti e le azioni di Claude in ogni step.
Usarlo per: capire in quale fase si trova una ricerca, sapere cosa produrre dopo,
non saltare passaggi critici.

---

## MAPPA DEL PROCESSO

```
FASE 0 — Acquisizione mandato
    ↓
FASE 1 — Preparazione kick-off
    ↓
FASE 2 — Kick-off con il cliente
    ↓
FASE 3 — Post kick-off (JD + scorecard draft)
    ↓
FASE 4 — Sourcing e triage CV
    ↓
FASE 5 — Outreach e primo contatto
    ↓
FASE 6 — Colloquio con il candidato
    ↓
FASE 7 — Scorecard e presentazione al cliente
    ↓
FASE 8 — Gestione iter (step con il cliente)
    ↓
FASE 9 — Pre-offerta e chiusura
    ↓
FASE 10 — Post-firma e handoff
```

---

## FASE 0 — ACQUISIZIONE MANDATO

**Trigger:** Il cliente contatta Katia per aprire una ricerca.

**Input necessari:**
- Brief iniziale del cliente (anche informale)
- JD originale se disponibile
- Nome referente e ruolo

**Azioni di Katia:**
- Valutare se il mandato è fattibile (profilo realistico? budget allineato al mercato?)
- Definire i termini commerciali (fee, esclusiva/non esclusiva, durata)
- Firmare il contratto di ricerca PRIMA di avviare qualsiasi attività

**Output:**
- Contratto di ricerca firmato
- Brief iniziale salvato nell'ATS

**Segnale di completamento:** Contratto firmato → si può passare alla Fase 1.

**Red flag da bloccare qui:**
- Cliente che vuole iniziare "in prova" senza contratto
- Budget chiaramente sotto mercato senza volontà di rinegoziare
- Profilo impossibile senza flessibilità dichiarata

---

## FASE 1 — PREPARAZIONE KICK-OFF

**Trigger:** Contratto firmato, kick-off schedulato.

**Input necessari:**
- Nome azienda cliente
- JD originale (se disponibile)
- Nome e ruolo del referente

**Cosa fa Claude:**
Leggere la SKILL `recruiter-kickoff` → sezione FASE 1.
Produrre un briefing pre-call con:
- Deep search azienda (settore, stage, funding, stack, cultura, notizie recenti)
- Analisi critica della JD originale (requisiti realistici vs inflazionati, incoerenze)
- Ipotesi sul candidato ideale da verificare in call
- Red flag da esplorare
- Domande challenger da preparare
- Ipotesi di pool size per lo stack richiesto

**Output:**
- Documento "Briefing pre kick-off [Cliente] — [Ruolo]"
- Lista domande prioritarie per la call

**Tempo indicativo:** 30-45 minuti prima della call.

---

## FASE 2 — KICK-OFF CON IL CLIENTE

**Trigger:** Call schedulata con il referente cliente.

**Input necessari:**
- Briefing pre-call (Fase 1)
- Accesso alla call (Katia conduce)

**Struttura della call (in ordine flessibile):**
1. Contesto decisionale (chi decide, perché adesso, tentativi precedenti)
2. Compensation package completo (RAL, CCNL, bonus, stock, benefit)
3. Il ruolo (cosa farà / NON farà, 30-60-90 giorni, reporting line)
4. Il team (composizione, stack aziendale completo, progetto)
5. Must Have / Nice to Have (max 3 MH assoluti — usare MoSCoW)
6. Logistica (sede, smart working, trasferte, relocation)
7. Processo di selezione (step, chi coinvolto, time-to-hire)
8. Sourcing (aziende donor, aziende no-touch, candidati già visti)
9. Selling points reali dell'azienda

**Obiettivo SMART da definire in call:**
"Presentare X candidati allineati entro Y settimane dalla firma del contratto."

**Cosa fa Claude (se Katia incolla il transcript):**
→ Passare direttamente alla Fase 3.

**Output della call:**
- Transcript (registrazione o note)
- Accordo su obiettivo e timeline

---

## FASE 3 — POST KICK-OFF

**Trigger:** Transcript del kick-off disponibile.

**Input necessari:**
- Transcript kick-off (testo grezzo, anche informale)
- JD originale del cliente (se non già fornita prima)

**Cosa fa Claude:**
1. Estrarre e strutturare tutti i dati raccolti
2. Identificare gap informativi (cosa non è stato chiarito → lista domande di follow-up)
3. Segnalare incoerenze o red flag emersi
4. Valutare realisticità del profilo richiesto vs mercato italiano
5. Riscrivere la JD (formato LinkedIn, tono diretto, 3-4 domande di scrematura yes/no)
6. Produrre la struttura della scorecard con i criteri del kick-off
7. Produrre la strategia di sourcing (pool size stimato, aziende target, booleane)

**Output:**
- JD riscritta (pronta per pubblicazione LinkedIn)
- Struttura scorecard (criteri pre-screening)
- Note di follow-up per il cliente (se ci sono gap)
- Strategia sourcing con Tier 1/2/3 aziende target e booleane

**Segnale di completamento:** JD approvata dal cliente → si pubblica e si avvia il sourcing.

---

## FASE 4 — SOURCING E TRIAGE CV

**Trigger:** JD pubblicata e/o sourcing attivo su LinkedIn.

**Input necessari per il triage:**
- CV del candidato (PDF, testo o link LinkedIn)
- Transcript kick-off (o criteri estratti nella Fase 3)

**Fonti di candidature:**
- Candidature dirette dal post LinkedIn
- Sourcing attivo booleano su LinkedIn Recruiter
- Community (Kubernetes Italia Slack, Gopher Italia, DevOps Heroes, ecc.)
- GitHub cross-check per ruoli tecnici
- Referral da network

**Cosa fa Claude per ogni CV:**
- Triage Tier 1 / Tier 2 / KO rispetto ai must have del kick-off
- Per i Tier 1: punti di forza rispetto al ruolo (con evidenze dal CV), gap potenziali, domande specifiche da fare in colloquio, segnali di instabilità da chiarire
- Per i KO: motivazione sintetica

**Regola della reattività:**
I Tier 1 vanno contattati entro 24-48h dal triage. Il candidato IT è passivo e un ritardo
significa perderlo a favore di un competitor più veloce.

**Output:**
- Lista candidati con triage
- Per ogni Tier 1: scheda con punti di forza, gap, domande pre-colloquio

---

## FASE 5 — OUTREACH E PRIMO CONTATTO

**Trigger:** Candidato Tier 1 identificato.

**Input necessari:**
- Profilo LinkedIn del candidato
- Posizione aperta (JD riscritta + selling points)
- Link calendar di Katia

**Canali in ordine di efficacia:**
1. WhatsApp (se candidatura diretta e numero disponibile)
2. LinkedIn InMail (per outreach a freddo)
3. Email (meno efficace per profili passivi)

**Cosa fa Claude:**
- Messaggio LinkedIn outreach (max 300 caratteri, tech-friendly, personalizzato)
- Messaggio WhatsApp (più caldo, con link calendar)
- Varianti per candidature dirette vs sourcing attivo

**Protocollo follow-up:**
- Se non risponde in 5 giorni: un solo follow-up
- Se non risponde al follow-up: stop (no stalking)

**Output:**
- Messaggio outreach pronto da inviare
- Eventuale follow-up schedulato

---

## FASE 6 — COLLOQUIO CON IL CANDIDATO

**Trigger:** Candidato risponde e conferma la call.

**Input necessari:**
- CV del candidato
- Transcript kick-off (o criteri estratti)
- Eventuali domande specifiche identificate nel triage

**Preparazione (cosa fa Claude):**
- Lista domande personalizzate per quel candidato specifico
  (basate su CV + must have del kick-off + gap identificati nel triage)

**Struttura del colloquio (condotto da Katia):**
1. Blocco contrattuale (RAL attuale/desiderata, CCNL, notice period, benefit completo)
2. Blocco tecnico (stack, progetti, preferenze)
3. Blocco motivazionale (perché valuta, altri iter, controfferta, tempistiche)

**Post-colloquio (cosa fa Claude con il transcript):**
→ Passare direttamente alla Fase 7.

**Output:**
- Transcript del colloquio (registrazione o note)
- Feedback a caldo del candidato (chiamata o vocale subito dopo ogni step)

---

## FASE 7 — SCORECARD E PRESENTAZIONE AL CLIENTE

**Trigger:** Transcript colloquio disponibile.

**Input necessari:**
- Transcript colloquio candidato
- CV candidato
- Transcript kick-off (o criteri estratti nella Fase 3)

**Cosa fa Claude:**
Produrre scorecard completa con:
- Sezione Pre-Screening (tabella criteri del kick-off con esito ed evidenze)
- Note operative (sintesi pratica: package, tempistiche, situazione attuale)
- Valutazione Sintetica (tabella aree con evidenze oggettive + valutazione consulenziale)
- Executive Assessment (overall fit % + paragrafo narrativo)
- Hiring Risk Matrix (rischi, probabilità, impatto, mitigazione)

**Principi della scorecard:**
- Evidenze concrete > opinioni generiche
- I punti di caduta si nominano, non si nascondono
- La valutazione consulenziale interpreta il dato, non lo ripete
- Il cliente deve poter decidere leggendo solo la scorecard

**Formato di presentazione al cliente:**
"Confidential + CV + scorecard nel corpo della mail" (o piattaforma ATS condivisa)

**Output:**
- Scorecard completa
- Email/messaggio di presentazione al cliente

**Segnale di completamento:** Candidato presentato → step schedulato con il cliente.

---

## FASE 8 — GESTIONE ITER (STEP CON IL CLIENTE)

**Trigger:** Step schedulato tra candidato e cliente.

**Cosa fa Katia prima di ogni step:**
- Chiamata al candidato per prepararlo (cosa aspettarsi, come prepararsi)
- Conferma della motivazione e assenza di sviluppi su altri fronti

**Cosa fa Katia dopo ogni step:**
- Chiamata al candidato a caldo (o richiesta di vocale immediato)
- Raccolta feedback dal cliente (entro 48h — se tarda, sollecitare)
- Se feedback negativo generico: ricostruirlo in base ai punti di caduta della scorecard

**Cosa fa Claude:**
- Suggerire le domande di feedback da fare al candidato e al cliente
- Se il feedback è generico: proporre una versione ricostruita da trasmettere al candidato
- Diagnosticare eventuali blocchi (stakeholder difficile? scope creep? candidato che tentenna?)

**Output dopo ogni step:**
- Feedback candidato raccolto
- Feedback cliente raccolto
- Aggiornamento stato nell'ATS
- Next step definito con deadline

**Segnali di allerta da gestire in questa fase:**
- Cliente che non risponde in 48h → protocollo ghosting cliente
- Candidato che inizia a essere vago → approfondire motivazione
- Nuovo iter del candidato emerso → riallineare priorità pre-offerta

---

## FASE 9 — PRE-OFFERTA E CHIUSURA

**Trigger:** Cliente anticipa che sta formulando l'offerta.

**PRIMA che esca la lettera — call con il candidato:**

1. Dare feedback positivo (senza garantire JO)
2. "Stanno valutando anche altri profili, ma ho un buon presentimento"
3. "A valle di tutti i passaggi, quale offerta riterresti onesta per accettare?"
4. "Scordiamo la RAL — è un lavoro che vorrebbe? Se no, fermiamoci qui."
5. Scala di interesse 1-10: "Dove si posiziona rispetto alle altre opportunità?"
6. Se 8-9: "Cosa dovrebbe avere questa JO per arrivare a 10?"
7. Se <7: non portare l'offerta — esplorare prima i dubbi
8. Esplorare motivazioni nascoste (coniuge, timing, paura del cambiamento)

**Analisi comparativa se ci sono JO concorrenti:**
- Costruire la tabella 90% / 50% / 5% per ogni offerta
- Presentare il confronto al candidato in modo oggettivo

**Cosa fa Claude:**
- Preparare la struttura della call pre-offerta
- Costruire la tabella comparativa delle offerte
- Suggerire come gestire eventuali sgambetti negoziali (scadenza artificiale,
  mancanza di autorità, piccole concessioni post-accordo)

**Lettera d'impegno — esce solo quando:**
- Candidato ha verbalmente accettato
- Tutti i dubbi sono stati smarcati
- Punteggio 9-10
- Nessun altro iter in fase avanzata non gestito

**Output:**
- Note call pre-offerta
- Tabella comparativa offerte (se necessario)
- OK al cliente per procedere con la lettera

---

## FASE 10 — POST-FIRMA E HANDOFF

**Trigger:** Candidato firma la lettera d'impegno.

**Azioni immediate:**
- Chiamata di congratulazioni al candidato
- Comunicazione al cliente con conferma
- Aggiornamento ATS (chiusura mandato)

**Check-in pre-start:**
Nella settimana tra firma e primo giorno: breve chiamata di verifica.
"Come si sente? Ha già comunicato le dimissioni? Ci sono stati sviluppi?"
Obiettivo: prevenire il ghosting post-firma (la causa più comune è la controfferta
ricevuta durante il preavviso).

**Se il candidato non si presenta:**
- Comunicare subito al cliente
- Offrire di riattivare la pipeline con priorità
- Non sparire — gestire la situazione professionalmente

**Raccolta referral:**
Dopo il placement, chiedere al candidato e al cliente un referral o una testimonianza.
Il mercato IT Milano è piccolo — ogni placement è un'opportunità di network.

**Output finale:**
- Mandato chiuso nell'ATS
- Feedback del cliente raccolto (utile per futuri mandati)
- Eventuale referral o testimonianza

---

## CHECKLIST RAPIDA PER FASE

| Fase | Input che serve | Output che produce Claude |
|---|---|---|
| 0 — Acquisizione | Brief informale | Valutazione fattibilità |
| 1 — Prep kick-off | Nome azienda + JD | Briefing pre-call + domande |
| 2 — Kick-off | — (Katia conduce) | — |
| 3 — Post kick-off | Transcript kick-off | JD riscritta + scorecard draft + sourcing |
| 4 — Triage CV | CV + criteri kick-off | Tier 1/2/KO + domande per colloquio |
| 5 — Outreach | Profilo + JD | Messaggio LinkedIn/WhatsApp |
| 6 — Prep colloquio | CV + criteri | Domande personalizzate |
| 7 — Scorecard | Transcript colloquio + CV + kick-off | Scorecard completa |
| 8 — Gestione iter | Feedback grezzo | Feedback ricostruito + diagnostica blocchi |
| 9 — Pre-offerta | Dettagli offerta + altri iter | Call pre-offerta + tabella comparativa |
| 10 — Post-firma | — | Check-in script + chiusura |

---

## TIMING DI RIFERIMENTO (mercato IT Milano)

- Kick-off → prima shortlist: 1-2 settimane
- Primo round colloqui → feedback cliente: 48h max
- Candidato presentato → step schedulato: max 5 giorni lavorativi
- Ultimo step → offerta: 24-48h (i candidati top hanno 2-3 processi in parallelo)
- Target time-to-hire: 4-8 settimane dalla firma del contratto di ricerca
- Preavviso medio mercato IT senior: 2-3 mesi

**Regola d'oro sulla velocità:**
Ogni giorno di ritardo nel dare feedback è un giorno in cui il candidato avanza
in un altro processo. La velocità è un vantaggio competitivo nel mercato IT.
