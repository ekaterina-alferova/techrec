# Time Management — Recruiter in Consulenza e Talent Acquisition

## COME USARE QUESTO FILE
Framework per gestire il calendario, prioritizzare le ricerche e il business development
quando si lavora su più mandati in parallelo. Applicabile sia ai recruiter freelance/consulenza
(che devono anche vendere e fatturare) sia ai recruiter interni (TA) con più posizioni aperte.

---

## IL PROBLEMA REALE

Un recruiter in consulenza ha due mestieri simultanei:
1. **Delivery** — trovare candidati, gestire iter, chiudere posizioni
2. **Business development** — trovare nuovi clienti, coltivare relazioni, proporre nuovi mandati

Il rischio più comune: si consuma tutto il tempo sul delivery e si smette di vendere.
Poi si chiude una ricerca e non c'è niente in pipeline.
Oppure si passa troppo tempo su mandati a bassa probabilità di chiusura
e si trascurano quelli dove il candidato è quasi pronto.

---

## FRAMEWORK DI PRIORITIZZAZIONE — MATRICE URGENZA/VALORE

Ogni mandato e ogni attività va classificata su due assi:

**Asse 1 — Urgenza:** quanto è urgente per il cliente / per la pipeline?
**Asse 2 — Valore economico e strategico:** quanto vale questa chiusura (fee) o questa relazione?

```
                    ALTA URGENZA
                        |
            Q1          |          Q2
        ESEGUIRE ORA    |      PIANIFICARE
        (deadline       |      (importante ma
         imminente,     |       non brucia)
         candidato      |
         in offerta)    |
  BASSO  ───────────────┼─────────────────── ALTO
  VALORE                |                   VALORE
            Q3          |          Q4
        DELEGARE O      |      INVESTIRE
        ELIMINARE       |      (BD, relazioni,
        (urgente ma     |       nuovi mandati
         basso valore)  |       alto potenziale)
                        |
                    BASSA URGENZA
```

### Q1 — ESEGUIRE ORA (alta urgenza + alto valore)
Esempi: candidato con offerta concorrente, lettera d'impegno in arrivo, feedback da dare entro 24h,
cliente che aspetta la shortlist da giorni, iter che rischia di perdere il candidato.
→ Nessun altro impegno batte questi. Entrano nel calendario della mattina, non del pomeriggio.

### Q2 — PIANIFICARE (bassa urgenza + alto valore)
Esempi: ricerca con buon potenziale ma appena avviata, relazione con cliente strategico da coltivare,
proposta commerciale da preparare, kick-off da fare bene senza fretta.
→ Vanno nel calendario con slot dedicati e protetti. Senza pianificazione diventano Q1 in emergenza.

### Q3 — DELEGARE O ELIMINARE (alta urgenza + basso valore)
Esempi: burocrazia, report che nessuno legge, riunioni senza output, richieste di clienti
non profittevoli che consumano tempo, mandati con probabilità di chiusura molto bassa.
→ Minimizzare. Se non si può delegare, fare in blocchi di tempo dedicati (non durante le ore prime).

### Q4 — INVESTIRE CON METODO (bassa urgenza + alto valore strategico)
Esempi: business development, costruzione network, aggiornamento su stack tecnologici,
miglioramento processi, coltivare relazioni con clienti dormienti.
→ Il quadrante più trascurato. Richiede slot protetti nella settimana — non aspettare di avere tempo libero.

---

## PIANIFICAZIONE SETTIMANALE — STRUTTURA TIPO

### Lunedì mattina (30-45 min): review e pianificazione
- Stato di ogni mandato attivo: in quale fase? Cosa si sblocca questa settimana?
- Candidati con step schedulati: chi ha un colloquio? Chi aspetta feedback?
- Pipeline BD: chi contattare, quale proposta mandare, quale cliente coltivare?
- Output: lista priorità settimanali con Q1/Q2/Q3/Q4 assegnato

### Slot mattutini (energie alte): Q1 e Q2
- Colloqui con candidati
- Scorecards da scrivere
- Presentazioni candidati al cliente
- Preparazione kick-off
- Business development attivo (email, proposte commerciali, call nuovi clienti)

### Slot pomeridiani (energie medie): attività operative
- Sourcing e triage CV
- Outreach LinkedIn/WhatsApp
- Follow-up candidati e clienti
- Aggiornamento ATS
- Risposta email

### Fine settimana (venerdì, 20 min): review
- Cosa si è chiuso? Cosa è rimasto aperto?
- Cosa rischia di diventare urgente la settimana prossima?
- Aggiornare forecast fatturato

---

## GESTIONE MANDATI IN PARALLELO

### Quanti mandati si possono gestire in parallelo?
Dipende dalla fase: un mandato in fase di sourcing pesa molto meno di uno in fase di iter attivo.

| Fase del mandato | Peso settimanale stimato |
|---|---|
| Kick-off + post kick-off | 4-6 ore (concentrato) |
| Sourcing attivo | 3-5 ore/settimana |
| Iter candidati attivo (2-3 candidati in step) | 5-8 ore/settimana |
| Pre-offerta / chiusura | 3-5 ore (concentrato) |
| Mandato in stallo (cliente fermo) | 30 min/settimana (touchpoint) |

**Soglia di attenzione:** se hai più di 3-4 mandati in fase di iter attivo simultaneamente,
la qualità del lavoro cala e i candidati lo percepiscono.
Meglio pochi mandati gestiti bene che molti gestiti male.

### Come decidere se accettare un nuovo mandato
Prima di dire sì a un nuovo mandato, rispondere a tre domande:
1. Ho slot reali nel calendario per fare sourcing + colloqui nelle prossime 2 settimane?
2. Il fee potenziale giustifica l'investimento di tempo rispetto ai mandati già in corso?
3. La probabilità di chiusura è realistica (cliente serio, budget confermato, processo definito)?
Se anche una delle tre risposte è no: negoziare condizioni migliori o rimandare.

---

## GESTIONE DELLA FATTURAZIONE (per consulenza freelance)

### Il rischio del "dimenticarsi di vendere"
Quando si è nel pieno di iter attivi, il BD si ferma.
Poi si chiude la ricerca e la pipeline è vuota — il cosiddetto "feast or famine cycle".

**Regola pratica:** riservare almeno 2-3 ore a settimana al BD anche nelle settimane di picco delivery.
Non è negoziabile — va messo nel calendario come un colloquio con un candidato.

### Forecast fatturato — visibilità minima
Tenere sempre aggiornata una stima semplice:

| Mandato | Fee potenziale | Probabilità chiusura | Fee atteso | Mese stimato |
|---|---|---|---|---|
| Cliente A - Backend Dev | €X | 80% | €X×0,8 | Maggio |
| Cliente B - EM | €X | 40% | €X×0,4 | Giugno |
| Cliente C - DevOps | €X | 20% | €X×0,2 | ? |

Questo permette di capire subito quando la pipeline si svuota e quando accelerare il BD.

### Prioritizzare i mandati per probabilità di chiusura × valore
Non tutti i mandati meritano lo stesso tempo. Priorità a:
- Mandati con candidati già in fase avanzata (alto ROI sul tempo investito)
- Clienti con fee più alto e processo decisionale rapido
- Mandati esclusivi vs non esclusivi (l'esclusiva vale di più in termini di tempo da investire)

---

## TIME BOXING — BLOCCHI DI TEMPO DEDICATI

### Principio
Non lavorare "a flusso" su tutto. Assegnare ogni tipo di attività a un blocco specifico.
Cambiare continuamente contesto (da sourcing a email a colloquio a BD) è il modo più veloce
per perdere produttività e fare tutto male.

### Blocchi consigliati per una giornata tipo

**Blocco 1 — 9:00-11:00: Lavoro di qualità**
Scorecards, presentazioni candidati, kick-off, proposte commerciali.
Niente email, niente WhatsApp. Telefono in silenzio salvo urgenze vere.

**Blocco 2 — 11:00-13:00: Colloqui e call**
Tutti i colloqui con candidati e clienti concentrati qui. Back-to-back se possibile.

**Blocco 3 — 14:30-16:30: Sourcing e outreach**
Triage CV, booleane LinkedIn, messaggi outreach, follow-up.
Attività che richiedono concentrazione media ma non le energie delle 9 del mattino.

**Blocco 4 — 16:30-17:30: Operativo e admin**
Email, ATS, aggiornamenti, call veloci di feedback. Attività a bassa intensità cognitiva.

### Proteggere i blocchi
I blocchi di lavoro di qualità (Blocco 1) vanno messi nel calendario come fossero
colloqui con un cliente importante. Non si spostano per email, non si interrompono per
WhatsApp. Chi lavora in consulenza tende a essere sempre "disponibile" — questo uccide la produttività.

---

## SEGNALI DI ALLARME — QUANDO IL TIME MANAGEMENT È FUORI CONTROLLO

- Stai sempre in modalità reattiva (rispondi a ciò che arriva, non lavori su priorità)
- Non riesci a fare BD perché sei "sempre troppo occupato con i mandati"
- I candidati aspettano feedback per più di 48h perché non hai tempo
- Non sai quante ore stai dedicando a ciascun mandato
- Il tuo fatturato ha picchi e vuoti forti — segno di pipeline mal gestita
- Stai lavorando su mandati che sai già che non chiuderai, per "non deludere il cliente"

### Azione correttiva immediata
1. Lista di tutti i mandati attivi con fase e probabilità di chiusura
2. Classificare ciascuno con Q1/Q2/Q3/Q4
3. Prendere una decisione esplicita sui Q3 — eliminarli o ridurli al minimo
4. Bloccare 2 slot BD fissi nella settimana successiva
5. Fare il punto ogni lunedì mattina per le prossime 4 settimane

---

## APPLICAZIONE IN TALENT ACQUISITION (ruoli interni)

Per i recruiter TA che gestiscono posizioni interne, il framework si adatta così:

- **Q1** → posizioni con hiring manager impaziente, candidato con offerta concorrente,
  posizione critica per il business (es. ruolo bloccante per un progetto)
- **Q2** → posizioni importanti ma con timeline più lunga, pipeline da costruire
- **Q3** → requisizioni aperte ma congelate di fatto, posizioni con JD ancora in revisione
- **Q4** → employer branding, miglioramento processi, relazioni con università/community

**La differenza principale rispetto alla consulenza:** non c'è il BD da gestire, ma c'è
la pressione degli stakeholder interni. Mappare gli stakeholder con la matrice (Capitolo
stakeholder-map) per capire a chi rispondere con priorità e come gestire chi pressa
senza avere potere decisionale reale.
