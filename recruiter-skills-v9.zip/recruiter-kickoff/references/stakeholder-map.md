# Stakeholder Map — Recruitment

## COME USARE QUESTO FILE
In ogni ricerca ci sono più attori con poteri e interessi diversi.
Capire chi hai davanti cambia come comunichi, a chi vai, chi usi come leva.
Usare questo file: prima del kick-off (chi sono gli stakeholder?), durante l'iter
(qualcuno sta rallentando il processo?), in fase di offerta (chi può bloccare?).

---

## LA MATRICE STAKEHOLDER

Gli stakeholder si classificano su due assi:
- **Potere decisionale** (alto / basso)
- **Interesse** (allineato al successo della ricerca / contrapposto)

```
                    INTERESSE CONTRAPPOSTO
                   |
ALTO    SABOTATORE | OPPOSITORE
POTERE             |
        -----------+----------
BASSO    INTRALCIO | SFIDANTE
                   |
                    INTERESSE CONTRAPPOSTO

                   |
ALTO    SOSTENITORE| GIGANTE SOPITO
POTERE             |
        -----------+----------
BASSO       AMICO  | FAMILIARE
                   |
                    INTERESSE ALLINEATO
```

---

## I PROFILI IN DETTAGLIO

### 🔴 SABOTATORE — Potere Alto / Interesse Contrapposto
**Strategia: Evitare**

Chi è nel recruitment: CEO/AD/CFO che non condivide la posizione da assumere,
partner che boicotta la ricerca attivamente (es. "non abbiamo budget" ma budget c'è).

Come riconoscerlo: blocca budget o colloqui, non risponde, crea ostacoli procedurali,
rimanda le decisioni senza motivo apparente.

Come gestirlo:
- Minimizzare l'esposizione — non affidargli step critici
- Tenere aggiornato con informazioni strategiche, non operative
- Trovare un sostenitore che faccia da scudo o da mediatore
- Non combatterlo frontalmente — usa i dati per spostare il potere

---

### 🟠 OPPOSITORE — Potere Alto / Interesse Basso o Contrapposto
**Strategia: Depotenziarlo**

Chi è nel recruitment: HRBP che fa muro, partner che rallenta il processo passivamente,
hiring manager che non crede nel profilo cercato.

Come riconoscerlo: non è apertamente ostile ma non supporta. Risponde in ritardo,
dà feedback vaghi, "dimentica" di schedulare i colloqui.

Come gestirlo:
- Ridurre il suo controllo sul processo — coinvolgerlo solo dove necessario
- Usare dati concreti per convincerlo (pool size, benchmark di mercato)
- Coinvolgerlo in fasi a basso rischio per non dargli leve di blocco

---

### 🟢 SOSTENITORE — Potere Alto / Interesse Alto e Allineato
**Strategia: Sfruttarlo**

Chi è nel recruitment: referente HR motivato, hiring manager entusiasta della ricerca,
partner commerciale che vuole chiudere velocemente.

Come gestirlo:
- Affidargli i passaggi chiave (feedback rapidi, sblocco decisionale)
- Usarlo per sbloccare altri stakeholder difficili
- Coinvolgerlo nella comunicazione con i candidati top
- Tenerlo informato — è il tuo alleato principale

---

### 🟡 GIGANTE SOPITO — Potere Alto / Interesse Basso o Neutro
**Strategia: Interessarlo con cautela**

Chi è nel recruitment: CEO/AD che "lascia fare" ma può ribaltare tutto se si attiva.
Tipicamente: non segue il processo ma alla fine decide lui sull'offerta.

Come gestirlo:
- Tenerlo informato in modo strategico sui momenti chiave (non su tutto)
- Coinvolgerlo solo quando la decisione lo richiede
- Far leva su ciò che gli interessa (costo, velocità, rischio operativo)
- Non ignorarlo — se si sveglia dalla parte sbagliata, può bloccare tutto

---

### 🟢 AMICO — Potere Basso / Interesse Alto e Allineato
**Strategia: Fidarsi e usarlo come antenna**

Chi è nel recruitment: collega della delivery che conosce il cliente, HR del team cliente,
referente tecnico che vuole davvero il candidato giusto.

Come gestirlo:
- Collaborazione fluida — è un alleato affidabile
- Usarlo per raccogliere segnali interni (clima, priorità reali, dinamiche politiche)
- Può "preparare il terreno" prima che arrivi il candidato
- Non ha leve formali, ma è prezioso come fonte di informazioni

---

### ⚪ FAMILIARE — Potere Basso / Interesse Basso
**Strategia: Monitorare, non investire**

Chi è nel recruitment: dipendenti del cliente non coinvolti, team admin, figure periferiche.

Come gestirlo:
- Aggiornamenti minimi se richiesti
- Nessun coinvolgimento operativo
- Tenerlo d'occhio — potrebbe diventare rilevante se cambia il contesto

---

### 🔴 INTRALCIO — Potere Basso / Interesse Contrapposto
**Strategia: Monitorare, non combattere**

Chi è nel recruitment: referente del cliente che non crede di aver bisogno della risorsa,
collega critico del processo di selezione.

Come gestirlo:
- Non perdere tempo a convincerlo — non ha potere reale
- Tenerlo d'occhio per evitare sabotaggi indiretti (commenti negativi, ritardi intenzionali)
- Se diventa un problema, spostare la conversazione al sostenitore

---

### 🟠 SFIDANTE — Potere Basso / Interesse Alto ma Disallineato
**Strategia: Diffidare**

Chi è nel recruitment: stakeholder che vuole deviare il focus (propone profili non allineati
per interesse personale, spinge su candidati della propria rete).

Come gestirlo:
- Definire bene i confini del processo
- Ascoltare ma verificare sempre le informazioni che fornisce
- Non affidargli compiti critici
- Documentare le sue richieste — utile se la situazione escala

---

## APPLICAZIONE PRATICA

### Prima del kick-off
Identificare mentalmente gli stakeholder della ricerca:
- Chi firma l'offerta? (spesso il vero decisore è diverso dal referente operativo)
- Chi fa i colloqui tecnici? Sono allineati sul profilo?
- C'è qualcuno che potrebbe bloccare il processo?
- Chi è il mio sostenitore principale?

### Durante l'iter
Se il feedback tarda o il processo si blocca: diagnosticare chi sta rallentando e perché.
- Feedback lento dal sostenitore → problema operativo, spingere
- Feedback lento dall'oppositore → problema politico, cercare un bypass
- Silenzio del gigante sopito → preoccupante, trovare un modo per tenerlo informato

### In fase di offerta
Assicurarsi che il decisore finale (spesso il gigante sopito) sia stato preparato
PRIMA che esca la lettera. Non scoprire all'ultimo che il CEO non sapeva del candidato.
