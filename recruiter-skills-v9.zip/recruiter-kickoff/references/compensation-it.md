# Compensation Reference — Mercato IT Italiano

## COME USARE QUESTO FILE
Usare questo file durante il kick-off (per sfidare il budget del cliente),
durante il colloquio con il candidato (per ricostruire il package completo),
e in fase di pre-offerta (per fare l'analisi comparativa JO).

---

## TABELLA RAL → NETTO MENSILE — DATI UFFICIALI (Schema Retributivo Candidati)

Fonte: tabella ufficiale "Schema Retributivo Candidati" — dati precisi, non stime.
I valori netto sono indicativi e possono subire lievi variazioni in base a specifici
elementi retributivi aggiuntivi (addizionali comunali, regionali, ecc.).

### Tabella completa — 13 mensilità e 14 mensilità a confronto

| RAL | Lordo/mese (13) | **Netto/mese (13)** | Lordo/mese (14) | **Netto/mese (14)** |
|---|---|---|---|---|
| €18.000 | €1.384,62 | **€1.262** | €1.285,71 | **€1.172** |
| €19.000 | €1.461,54 | **€1.301** | €1.357,14 | **€1.210** |
| €20.000 | €1.538,46 | **€1.342** | €1.428,57 | **€1.238** |
| €21.000 | €1.615,38 | **€1.383** | €1.500,00 | **€1.278** |
| €22.000 | €1.692,31 | **€1.424** | €1.571,43 | **€1.313** |
| €23.000 | €1.769,23 | **€1.465** | €1.642,86 | **€1.355** |
| €24.000 | €1.846,15 | **€1.506** | €1.714,29 | **€1.396** |
| €25.000 | €1.923,08 | **€1.547** | €1.785,71 | **€1.438** |
| €26.000 | €2.000,00 | **€1.588** | €1.857,14 | **€1.479** |
| €27.000 | €2.076,92 | **€1.629** | €1.928,57 | **€1.515** |
| €28.000 | €2.153,85 | **€1.675** | €2.000,00 | **€1.562** |
| €29.000 | €2.230,77 | **€1.716** | €2.071,43 | **€1.595** |
| €30.000 | €2.307,69 | **€1.757** | €2.142,86 | **€1.645** |
| €31.000 | €2.384,62 | **€1.797** | €2.214,29 | **€1.670** |
| €32.000 | €2.461,54 | **€1.835** | €2.285,71 | **€1.722** |
| €33.000 | €2.538,46 | **€1.873** | €2.357,14 | **€1.747** |
| €34.000 | €2.615,38 | **€1.919** | €2.428,57 | **€1.792** |
| €35.000 | €2.692,31 | **€1.938** | €2.500,00 | **€1.812** |
| €36.000 | €2.769,23 | **€1.975** | €2.571,43 | **€1.848** |
| €37.000 | €2.846,15 | **€2.013** | €2.642,86 | **€1.883** |
| €38.000 | €2.923,08 | **€2.051** | €2.714,29 | **€1.907** |
| €39.000 | €3.000,00 | **€2.084** | €2.785,71 | **€1.937** |
| €40.000 | €3.076,92 | **€2.122** | €2.857,14 | **€1.972** |
| €41.000 | €3.153,85 | **€2.159** | €2.928,57 | **€2.007** |
| €42.000 | €3.230,77 | **€2.197** | €3.000,00 | **€2.042** |
| €43.000 | €3.307,69 | **€2.235** | €3.071,43 | **€2.078** |
| €44.000 | €3.384,62 | **€2.273** | €3.142,86 | **€2.113** |
| €45.000 | €3.461,54 | **€2.313** | €3.214,29 | **€2.148** |
| €46.000 | €3.538,46 | **€2.348** | €3.285,71 | **€2.193** |
| €47.000 | €3.615,38 | **€2.386** | €3.357,14 | **€2.218** |
| €48.000 | €3.692,31 | **€2.424** | €3.428,57 | **€2.253** |
| €49.000 | €3.769,23 | **€2.462** | €3.500,00 | **€2.288** |
| €50.000 | €3.846,15 | **€2.500** | €3.571,43 | **€2.323** |
| €51.000 | €3.923,08 | **€2.538** | €3.642,86 | **€2.358** |
| €52.000 | €4.000,00 | **€2.575** | €3.714,29 | **€2.394** |
| €53.000 | €4.076,92 | **€2.613** | €3.785,71 | **€2.429** |
| €54.000 | €4.153,85 | **€2.651** | €3.857,14 | **€2.474** |
| €55.000 | €4.230,77 | **€2.689** | €3.928,57 | **€2.499** |
| €56.000 | €4.307,69 | **€2.727** | €4.000,00 | **€2.534** |
| €57.000 | €4.384,62 | **€2.765** | €4.071,43 | **€2.570** |
| €58.000 | €4.461,54 | **€2.804** | €4.142,86 | **€2.605** |
| €59.000 | €4.538,46 | **€2.842** | €4.214,29 | **€2.641** |
| €60.000 | €4.615,38 | **€2.880** | €4.285,71 | **€2.677** |
| €61.000 | €4.692,31 | **€2.918** | €4.357,14 | **€2.712** |
| €62.000 | €4.769,23 | **€2.957** | €4.428,57 | **€2.748** |
| €63.000 | €4.846,15 | **€2.995** | €4.500,00 | **€2.783** |
| €64.000 | €4.923,08 | **€3.033** | €4.571,43 | **€2.819** |
| €65.000 | €5.000,00 | **€3.071** | €4.642,86 | **€2.854** |
| €66.000 | €5.076,92 | **€3.110** | €4.714,29 | **€2.890** |
| €67.000 | €5.153,85 | **€3.148** | €4.785,71 | **€2.925** |
| €68.000 | €5.230,77 | **€3.186** | €4.857,14 | **€2.961** |
| €69.000 | €5.307,69 | **€3.225** | €4.928,57 | **€2.996** |
| €70.000 | €5.384,62 | **€3.263** | €5.000,00 | **€3.032** |
| €71.000 | €5.461,54 | **€3.301** | €5.071,43 | **€3.068** |
| €72.000 | €5.538,46 | **€3.339** | €5.142,86 | **€3.103** |
| €73.000 | €5.615,38 | **€3.378** | €5.214,29 | **€3.139** |
| €74.000 | €5.692,31 | **€3.416** | €5.285,71 | **€3.174** |
| €75.000 | €5.769,23 | **€3.454** | €5.357,14 | **€3.210** |
| €76.000 | €5.846,15 | **€3.493** | €5.428,57 | **€3.245** |
| €77.000 | €5.923,08 | **€3.531** | €5.500,00 | **€3.281** |
| €78.000 | €6.000,00 | **€3.569** | €5.571,43 | **€3.316** |
| €79.000 | €6.076,92 | **€3.603** | €5.642,86 | **€3.252** |
| €80.000 | €6.153,85 | **€3.646** | €5.714,29 | **€3.387** |
| €81.000 | €6.230,77 | **€3.684** | €5.785,71 | **€3.424** |
| €82.000 | €6.307,69 | **€3.722** | €5.857,14 | **€3.459** |
| €83.000 | €6.384,62 | **€3.761** | €5.928,57 | **€3.494** |
| €84.000 | €6.461,54 | **€3.799** | €6.000,00 | **€3.530** |
| €85.000 | €6.538,46 | **€3.837** | €6.071,43 | **€3.565** |
| €86.000 | €6.615,38 | **€3.875** | €6.142,86 | **€3.601** |
| €87.000 | €6.692,31 | **€3.914** | €6.214,29 | **€3.636** |
| €88.000 | €6.769,23 | **€3.952** | €6.285,71 | **€3.672** |
| €89.000 | €6.846,15 | **€3.990** | €6.357,14 | **€3.707** |
| €90.000 | €6.923,08 | **€4.028** | €6.428,57 | **€3.743** |
| €91.000 | €7.000,00 | **€4.067** | €6.500,00 | **€3.778** |
| €92.000 | €7.076,92 | **€4.105** | €6.571,43 | **€3.814** |
| €93.000 | €7.153,85 | **€4.143** | €6.642,86 | **€3.850** |
| €94.000 | €7.230,77 | **€4.182** | €6.714,29 | **€3.885** |
| €95.000 | €7.307,69 | **€4.220** | €6.785,71 | **€3.921** |
| €96.000 | €7.384,62 | **€4.258** | €6.857,14 | **€3.956** |
| €97.000 | €7.461,54 | **€4.296** | €6.928,57 | **€3.992** |
| €98.000 | €7.538,46 | **€4.335** | €7.000,00 | **€4.027** |
| €99.000 | €7.615,38 | **€4.373** | €7.071,43 | **€4.063** |
| €100.000 | €7.692,31 | **€4.411** | €7.142,86 | **€4.098** |
| €101.000 | €7.769,23 | **€4.450** | €7.214,29 | **€4.134** |
| €102.000 | €7.846,15 | **€4.488** | €7.285,71 | **€4.169** |
| €103.000 | €7.923,08 | **€4.526** | €7.357,14 | **€4.205** |
| €104.000 | €8.000,00 | **€4.564** | €7.428,57 | **€4.241** |
| €105.000 | €8.076,92 | **€4.603** | €7.500,00 | **€4.276** |
| €106.000 | €8.153,85 | **€4.641** | €7.571,43 | **€4.312** |
| €107.000 | €8.230,77 | **€4.679** | €7.642,86 | **€4.347** |
| €108.000 | €8.307,69 | **€4.718** | €7.714,29 | **€4.383** |
| €109.000 | €8.384,62 | **€4.756** | €7.785,71 | **€4.418** |
| €110.000 | €8.461,54 | **€4.794** | €7.857,14 | **€4.454** |
| €111.000 | €8.538,46 | **€4.832** | €7.928,57 | **€4.489** |
| €112.000 | €8.615,38 | **€4.871** | €8.000,00 | **€4.525** |
| €113.000 | €8.692,31 | **€4.909** | €8.071,43 | **€4.560** |
| €114.000 | €8.769,23 | **€4.947** | €8.142,86 | **€4.596** |
| €115.000 | €8.846,15 | **€4.985** | €8.214,29 | **€4.632** |
| €116.000 | €8.923,08 | **€5.024** | €8.285,71 | **€4.667** |
| €117.000 | €9.000,00 | **€5.062** | €8.357,14 | **€4.703** |
| €118.000 | €9.076,92 | **€5.100** | €8.428,57 | **€4.738** |
| €119.000 | €9.153,85 | **€5.139** | €8.500,00 | **€4.774** |
| €120.000 | €9.230,77 | **€5.177** | €8.571,43 | **€4.809** |

**N.B.:** I valori netto sono indicativi e possono subire lievi variazioni in base a specifici
elementi retributivi aggiuntivi (addizionali comunali, regionali, ecc.).

**Come leggere la tabella:**
- 13 mensilità (CCNL Metalmeccanico): lordo mensile = RAL ÷ 13
- 14 mensilità (CCNL Commercio): lordo mensile = RAL ÷ 14
- Il netto è quello che il candidato riceve ogni mese in busta paga

**Costo azienda stimato** (da aggiungere al netto per capire il costo reale):
Il datore di lavoro paga circa il 28-32% in più rispetto alla RAL (contributi INPS,
INAIL, TFR). Regola rapida: RAL × 1,30 = costo azienda approssimativo.

**Differenza chiave tra i due CCNL:** a parità di RAL, con 13 mensilità il lordo mensile
è più alto ma si ricevono meno mensilità nell'anno. Con 14 mensilità il lordo mensile
è più basso ma si riceve una mensilità in più (luglio o agosto). Il netto annuale
totale è equivalente — cambia solo la distribuzione mensile.

---

## PREAVVISO — TABELLE UFFICIALI PER CCNL (Fonte: SINDA CARE CISL)

**IMPORTANTE per il recruitment:** ciò che conta è il preavviso in caso di **DIMISSIONI**
(il candidato che lascia), non di licenziamento. Le due tabelle sono diverse.
I termini decorrono dal 1° o dal 16° del mese (Commercio) o dalla metà/fine mese (Metalmeccanico).
Il preavviso è quasi sempre **negoziabile** nel mercato IT — chiedere sempre "è trattabile?"

---

### CCNL Commercio / Terziario — DIMISSIONI (giorni di calendario)

| Livello | Fino a 5 anni | 5-10 anni | Oltre 10 anni |
|---|---|---|---|
| Quadri, 1° livello | 45 giorni | 60 giorni | 90 giorni |
| 2°, 3° livello | 20 giorni | 30 giorni | 45 giorni |
| 4°, 5° livello | 15 giorni | 20 giorni | 30 giorni |
| 6°, 7° livello | 10 giorni | 15 giorni | 15 giorni |
| Operatori di vendita | 30 giorni | 45 giorni | 60 giorni |

*Termini di disdetta: decorrono dal 1° o dal 16° giorno di ciascun mese.*
*Forma: per iscritto con raccomandata o mezzo idoneo a certificare la data.*

**Per il licenziamento** (informazione utile per capire cosa offre il cliente ai candidati):
Quadri/1° livello: 60/90/120 gg · 2°-3° livello: 30/45/60 gg · 4°-5° livello: 20/30/45 gg

---

### CCNL Metalmeccanico Federmeccanica — DIMISSIONI (più diffuso nelle software house)

| Categoria | Fino a 5 anni | 5-10 anni | Oltre 10 anni |
|---|---|---|---|
| 1° Categoria (operaio base) | 7 giorni | 15 giorni | 20 giorni |
| 2°, 3° Categoria | 10 giorni | 20 giorni | 30 giorni |
| 4°, 5°, 5°S Categoria (impiegato/tecnico) | 1 mese e 15 gg | 2 mesi | 2 mesi e 15 gg |
| 6°, 7°, 8°Q Categoria (quadro/senior) | 2 mesi | 3 mesi | 4 mesi |

*Termini di disdetta: qualsiasi giorno del mese, decorrono dal giorno del ricevimento.*
*Il periodo di preavviso si calcola dal giorno successivo alla comunicazione.*

---

### CCNL Metalmeccanico Unionmeccanica — DIMISSIONI

| Categoria | Fino a 5 anni | 5-10 anni | Oltre 10 anni |
|---|---|---|---|
| 1° Categoria | 7 giorni | 15 giorni | 20 giorni |
| 2°, 3° Categoria | 10 giorni | 20 giorni | 30 giorni |
| 4°, 5°, 6° Categoria | 1 mese e 15 gg | 2 mesi | 2 mesi e 15 gg |
| 7°, 8°, 9° Categoria (quadro/senior) | 2 mesi | 3 mesi | 4 mesi |

---

### CCNL Metalmeccanico Artigianato — DIMISSIONI (impiegati)

| Categoria | Fino a 5 anni | 5-10 anni | Oltre 10 anni |
|---|---|---|---|
| 1°, 2° Categoria | 1 mese e ½ | 2 mesi | 2 mesi e ½ |
| 3°, 4°, 5°, 6° Categoria | 1 mese | 1 mese e ½ | 2 mesi |

*Termini di disdetta (impiegati): decorrono dalla metà o dalla fine di ciascun mese.*

---

### Traduzione pratica per il mercato IT

Nel colloquio con il candidato, mappare il livello contrattuale sulla realtà:

| Profilo IT reale | CCNL Commercio tipico | CCNL Metalmeccanico tipico | Preavviso dimissioni indicativo |
|---|---|---|---|
| Junior developer (0-3 anni) | 4°-5° livello | 3°-4° Categoria | 15-20 giorni (Comm.) / 10 gg-1 mese (Metal.) |
| Mid developer (3-6 anni) | 3°-4° livello | 4°-5° Categoria | 20-30 giorni (Comm.) / 1-2 mesi (Metal.) |
| Senior developer (6+ anni) | 2°-3° livello | 5°-6° Categoria | 30-45 giorni (Comm.) / 2-3 mesi (Metal.) |
| Tech Lead / Staff Eng. | 2° livello | 6°-7° Categoria | 45 giorni (Comm.) / 2-3 mesi (Metal.) |
| Engineering Manager / Quadro | Quadro / 1° livello | 7°-8°Q Categoria | 60-90 giorni (Comm.) / 3-4 mesi (Metal.) |

**Nota critica:** la categoria contrattuale spesso non corrisponde al titolo reale.
Chiedere sempre: "Che livello ha nel contratto?" — non "Che titolo ha?".
Un Senior con CCNL Commercio potrebbe avere 3° livello (30-45 gg) ma anche 2° (20-45 gg)
a seconda di come è stato inquadrato dall'azienda.

**Il preavviso è quasi sempre negoziabile** nel mercato IT senior. Un candidato motivato
riesce quasi sempre a uscire in 2-4 settimane indipendentemente dal contratto formale,
perché l'azienda accetta spesso di ridurre il preavviso in caso di dimissioni volontarie.

---

## P.IVA — COSTO REALE PER L'AZIENDA

P.IVA a €500-700/giorno lavorativo = costo annualizzato per l'azienda:
- €500/gg × 220 gg = €110.000/anno
- €700/gg × 220 gg = €154.000/anno

**Non è più conveniente dell'assunzione** una volta che si contabilizzano:
- Overhead di coordinamento (fatturazione, rinnovi contratto, no TFR accrual)
- Rischio continuità (il contractor può smettere con 30 giorni di preavviso contrattuale)
- Costi nascosti (nessuna ferie pagate, nessuna malattia garantita, nessun welfare)

**Per il candidato in P.IVA:**
L'imponibile dichiarato in dichiarazione dei redditi è la cifra da usare per il confronto
con la RAL dipendente. Chiedere: "Qual è stato il suo imponibile nell'ultima dichiarazione?"

---

## STOCK OPTION — LOGICA E TERMINOLOGIA

### Terminologia chiave

**Vesting:** il processo attraverso cui il dipendente "guadagna" le stock option nel tempo.
Esempio classico: 4 anni di vesting = ogni anno si sblocca il 25% delle opzioni totali.

**Cliff:** periodo iniziale in cui non si matura nulla. Se lasci prima del cliff, perdi tutto.
Esempio classico: 1 anno di cliff su 4 anni di vesting = nel primo anno non matura niente.
Dal mese 13 in poi: si sblocca il 25% (cliff) + un po' ogni mese fino al mese 48.

**Esempio pratico 4 anni vesting + 1 anno cliff:**
- Mese 0-12: niente (cliff)
- Mese 13: si sblocca il 25% (1 anno di cliff)
- Mese 14-48: si sblocca ~2% al mese fino al 100%
- Mese 48: 100% vested

**Strike price (prezzo di esercizio):** prezzo al quale il dipendente può comprare le azioni.
Viene fissato alla data di grant. Se il valore dell'azienda cresce, la differenza è il guadagno.

**Liquidity event:** l'evento che permette di convertire le stock in denaro contante.
- IPO (quotazione in borsa) → le azioni diventano vendibili sul mercato
- Acquisizione → l'acquirente compra le azioni a prezzo prestabilito
- Secondary market → vendita a investitori privati (raro, non garantito)

### Tre formule contrattuali da verificare
1. **"L'azienda SI OBBLIGA a comprare le stock in caso di liquidity event"** → soldi garantiti se il LE avviene
2. **"L'azienda PUÒ comprare le stock"** → non garantito, discrezionale
3. **LE previsto a breve (es. tra 6 mesi)** → probabilità alta di cash, ma timing incerto

### Come presentare le stock al candidato
Non vendere le stock come parte certa del compensation. Metterle sempre nella fascia
5% di probabilità dell'analisi JO comparativa, salvo LE già pianificato e documentato.
Chiedere al cliente: "Avete un liquidity event pianificato? In quale orizzonte temporale?"

### Domande da fare al candidato
- Quante opzioni ha (in unità o percentuale)?
- A quale strike price?
- Qual è la valutazione attuale dell'azienda (per stimare il potenziale valore)?
- Ha già fatto vesting parziale? Quanto perde se va via ora?
- C'è un liquidity event pianificato?

**Il "golden handcuff":** se un candidato ha già fatto 2 anni su 4 di vesting,
ha un costo concreto nel lasciare (perde il 50% che non ha ancora maturato).
Questo va messo sulla bilancia nella fase pre-JO.

---

## AUTO AZIENDALE — LOGICA E TABELLE ACI

### Categorie di auto aziendale
- **Solo uso lavorativo:** fringe benefit fiscalmente non imponibile, ma limitato
- **Uso promiscuo (lavorativo + personale):** il valore è calcolato come fringe benefit imponibile
- **Fuel card:** copre il carburante — verificare se illimitata o con tetto mensile
- **Rimborso km:** alternativa alla fuel card, calcolato sulle tabelle ACI

### Fringe benefit auto aziendale (uso promiscuo)
Il valore tassabile annuo è calcolato sulle tabelle ACI come percentuale del costo chilometrico
per 15.000 km/anno. Dal 2025 le percentuali variano in base alle emissioni CO2:
- Emissioni ≤60 g/km (ibrida/elettrica): 10% di 15.000 km × costo ACI
- Emissioni 61-160 g/km: 20%
- Emissioni 161-190 g/km: 30%
- Emissioni >190 g/km: 50%

### Come quantificare l'assenza di auto aziendale
Se il cliente non offre auto ma il candidato ce l'aveva:
1. Chiedere al candidato il modello e l'anno
2. Trovare il valore del fringe benefit sulle tabelle ACI (pubblicate annualmente)
3. Aggiungere il costo del carburante (se aveva fuel card)
4. Questa cifra è il "compenso nascosto" che va recuperato nella RAL

**Esempio:** candidato con BMW 320d (emissioni ~130 g/km):
- Costo ACI 2025 per 15.000 km: circa €0,45/km → €6.750/anno
- Fringe benefit imponibile al 20%: €1.350/anno lordo
- Fuel card ~€150/mese → €1.800/anno
- Totale da recuperare: circa €3.000-5.000 di RAL equivalente

---

## BUONI PASTO

Soglia di esenzione fiscale:
- Buoni pasto cartacei: esenti fino a €4/giorno
- Buoni pasto elettronici: esenti fino a €8/giorno

Valori tipici nel mercato IT Milano: €6-9/giorno (quasi sempre elettronici).
Un buono pasto da €8 × 220 giorni = €1.760/anno netti — da includere nell'analisi JO.

---

## WELFARE AZIENDALE

I piani welfare sono completamente esenti da contributi e imposte fino a €1.000/anno
(soglia 2024-2025, verificare aggiornamenti). I voucher sono spendibili in:
servizi per l'infanzia, palestre, corsi, rimborso utenze, buoni acquisto.

Un welfare da €600/anno equivale a ~€1.000 di RAL lorda (a seconda dello scaglione IRPEF).

---

## MBO / BONUS — COME LEGGERE I NUMERI

Quando il cliente dice "c'è un MBO del 15%", tradurlo per il candidato:
- MBO del 15% su RAL €70.000 = potenziale €10.500 lordi aggiuntivi
- Non è garantito: dipende da KPI individuali + aziendali
- Chiedere sempre al cliente: "Negli ultimi 3 anni, che % media dei target è stata raggiunta?"
- Chiedere: "Come vengono definiti i KPI? Chi li valida?"
- Se la risposta è vaga → mettere l'MBO nella fascia 50% di probabilità

**Premio aziendale (contrattuale):** previsto dal CCNL, legato alla produttività aziendale.
Importo tipico: €800-2.000/anno. Quasi sempre erogato (fascia 90%).

**Bonus overperformance:** discrezionale, raro. Fascia 5%.
