# IT Tech Stack Reference — Ruoli, Sinonimi, Ruoli Equivalenti

## COME USARE QUESTO FILE
Quando il cliente descrive un ruolo, cerca qui i sinonimi e i profili equivalenti
che allargano il pool di sourcing senza tradire i must have.
La logica è: partire dallo stack ideale, identificare il "ramp-up path" realistico,
capire da quali aziende e team specifici pescare.

---

## SVILUPPATORI BACKEND

### Go / Golang
**Titoli su LinkedIn:** Software Engineer (Go), Backend Engineer (Golang),
Platform Engineer, Site Reliability Engineer, Infrastructure Engineer,
Cloud Native Engineer, Systems Engineer

**Ruoli equivalenti con ramp-up 4-8 settimane:**
- Senior Java / Spring Boot con Kubernetes in produzione → Go è acquisibile, la mindset è quella
- C++ con sistemi distribuiti → ottima base per Go, soprattutto per performance engineering
- Rust developer → profilo raro ma con trasferibilità immediata

**Aziende target Milano per Go:**
Bending Spoons (Platform Eng), Mia-Platform (core product), SparkFabrik (cloud practice),
Satispay (infra/reliability), Prima Assicurazioni (platform/SRE), Vodafone IT (network APIs)

**Segnali positivi nel CV:**
Kubernetes operators, CRDs, controller-runtime, gRPC, Kafka, microservices at scale,
CNCF contributions, KubeCon speaker, ContainerDay, Cloud Native Milano meetup

**Red flag:**
"Ho lavorato con Go" senza repo pubblici né evidenze → verificare in colloquio tecnico
Go usato solo per scripting/tool → non è Go distributed systems

---

### Java / Spring Boot
**Titoli su LinkedIn:** Java Developer, Java Backend Engineer, Java Software Engineer,
Spring Developer, Microservices Engineer, Backend Tech Lead

**Ruoli equivalenti:**
- Kotlin developer (JVM, stessa mindset)
- Scala developer (JVM, spesso più senior e con background distribuito)
- Senior Java con Kafka, gRPC, Kubernetes → ottimo profilo per ruoli cloud-native

**Segnali positivi:** Spring Boot, Spring Cloud, Hibernate, Apache Kafka, Kubernetes,
AWS/GCP/Azure in produzione, microservices, DDD, clean architecture

**Aziende target Milano:**
Fineco Bank (architetture distribuite), Vodafone IT, Thoughtworks Milano,
Reply (multiple BU), Accenture (team architettura cloud), NTT Data

---

### Python
**Titoli su LinkedIn:** Python Developer, Backend Engineer (Python), Data Engineer,
ML Engineer, Python Software Engineer

**Framework:** Django, Flask, FastAPI, Celery
**Aziende target Milano:** Unibo/Unobravo (Flask), startup AI/ML, fintech

**Attenzione:** Python in data science ≠ Python in backend engineering.
Verificare sempre se ha costruito API, servizi, pipeline — non solo modelli.

---

### PHP
**Titoli su LinkedIn:** PHP Developer, Magento Developer, WordPress Developer,
Laravel Developer, Backend Developer (PHP)

**Framework:** Laravel (moderno, ottimo), Symfony (enterprise), CakePHP, WordPress
**Mercato:** Tecnologia datante, pool over 40. Difficile trovare PHP senior sotto i 38 anni.
Laravel è l'eccezione — community più giovane.

---

### .NET / C#
**Titoli su LinkedIn:** .NET Developer, C# Developer, .NET Core Engineer,
ASP.NET Developer, Full Stack .NET

**Aziende target:** Microsoft partner, PA digitale, enterprise italiano, banking

---

### Node.js
**Titoli su LinkedIn:** Node.js Developer, Backend JavaScript Engineer,
Full Stack Developer (Node), TypeScript Engineer

**Framework:** Express.js, Fastify, NestJS
**Nota:** Spesso i Node.js dev hanno anche competenze frontend (React/Vue).
Verificare se il ruolo richiede BE puro o full stack.

---

## SVILUPPATORI FRONTEND

### React / Next.js
**Titoli:** Frontend Developer, React Developer, Frontend Engineer, UI Engineer,
Next.js Developer

### Vue.js
**Titoli:** Vue Developer, Frontend Developer (Vue), JavaScript Engineer

### Angular
**Titoli:** Angular Developer, Frontend Engineer, TypeScript Developer

### Mobile
**iOS:** Swift Developer, iOS Developer, iOS Engineer (Objective-C per Sr con legacy)
**Android:** Kotlin Developer, Android Developer, Android Engineer
**Cross-platform:** Flutter Developer, React Native Developer

---

## FULL STACK

**Titoli:** Full Stack Developer, Full Stack Engineer, Software Engineer (Full Stack)
**Attenzione al cliente:** spesso vuole un full stack per risparmiare ma il ruolo è BE-heavy.
Verificare sempre la percentuale BE/FE attuale e la preferenza del candidato.

---

## DEVOPS / CLOUD / INFRA / SRE

**Titoli su LinkedIn:** DevOps Engineer, Platform Engineer, Site Reliability Engineer (SRE),
Cloud Engineer, Infrastructure Engineer, Cloud Architect, DevSecOps Engineer,
Kubernetes Engineer, Cloud Native Engineer

**Sinonimi per Kubernetes:** K8s Engineer, Container Orchestration, OpenShift (Red Hat K8s)

**Tecnologie chiave:** Kubernetes, Docker, Helm, Terraform, Ansible, CI/CD (GitLab CI,
GitHub Actions, Jenkins), AWS/Azure/GCP, Prometheus, Grafana, Istio, ArgoCD, Flux

**Certificazioni significative:**
- CKA (Certified Kubernetes Administrator) — hands-on, vale
- CKAD (Certified Kubernetes Application Developer)
- AWS Solutions Architect / DevOps Professional
- GCP Professional Cloud Architect

**Aziende target:** Akamai, AWS Milano, Dynatrace, Elastic IT, Mia-Platform,
SparkFabrik, Sysdig, Canonical Italia

---

## DATA / AI / ML

### Data Engineer
**Titoli:** Data Engineer, ETL Developer, Data Pipeline Engineer, Big Data Engineer
**Stack:** Python/Spark/Kafka, Airflow, dbt, Snowflake, Databricks, AWS Glue
**Attenzione:** Data Engineer ≠ Data Scientist ≠ Data Analyst — ruoli molto diversi

### Data Scientist
**Titoli:** Data Scientist, ML Engineer, Research Scientist, Applied Scientist
**Stack:** Python (pandas, scikit-learn, TensorFlow/PyTorch), R
**Nota:** Spesso background accademico (dottorato). Possono non conoscere il proprio
valore di mercato — attenzione nella negoziazione (ho visto profili passare da 32k a 50k+)

### Data Analyst / BI
**Titoli:** Data Analyst, Business Intelligence Developer, BI Developer,
PowerBI Developer, Tableau Developer
**Stack:** SQL, PowerBI, Tableau, QlikView, Looker

### AI / LLM Engineering (dal 2023 in forte crescita)
**Titoli:** AI Engineer, LLM Engineer, ML Platform Engineer, Prompt Engineer (attenzione),
Generative AI Engineer
**Stack:** Python, LangChain, LlamaIndex, OpenAI API, Hugging Face, RAG architectures,
vector databases (Pinecone, Weaviate, Qdrant)

---

## QA / TESTING

**Titoli:** QA Engineer, Software Tester, Test Automation Engineer, SDET,
Quality Assurance Engineer

**Manual vs Automation:** sempre chiarire. Il manual tester non è l'automation engineer.
**Stack automation:** Selenium, Cypress, Playwright, Appium (mobile), K6 (performance),
JMeter, pytest, JUnit

---

## SISTEMISTI / INFRA

### System Administrator / Sysadmin
**Titoli:** System Administrator, IT Administrator, Linux Administrator,
Infrastructure Administrator, Network Administrator

### Network Engineer
**Titoli:** Network Engineer, Network Administrator, NOC Engineer,
Telecom Engineer, SD-WAN Engineer

### Security / Cybersecurity
**Titoli:** Security Engineer, Penetration Tester, Ethical Hacker, SOC Analyst,
Information Security Engineer, AppSec Engineer, Cloud Security Engineer
**Certificazioni:** CEH, OSCP, CISSP, CompTIA Security+

---

## RUOLI ANALISTI

### Business Analyst / Functional Analyst
**Titoli:** Business Analyst, Functional Analyst, Systems Analyst, Requirements Engineer,
Product Owner (attenzione: ruolo diverso ma spesso usato come sinonimo impropriamente)
**Nota cliente frequente:** "vogliamo un BA" ma descrivono un PO, o viceversa. Chiarire.

### SAP Analyst/Developer
**Nota:** specificare sempre se funzionale o tecnico (ABAP).
Moduli principali: FI/CO (finance), MM (materials), SD (sales), HCM (HR), PP (production)

---

## RUOLI DIRIGENZIALI / LEADERSHIP

| Titolo richiesto dal cliente | Cosa intendono davvero (spesso) |
|---|---|
| CPO (Chief Product Officer) | Product Manager senior in un'azienda <50 persone |
| CTO | Tech Lead + Engineering Manager in startup <20 persone |
| Head of Engineering | Engineering Manager con team di 8-15 persone |
| Engineering Manager | Vedi sotto — ruolo molto variabile |
| Head of Product | Senior Product Manager |
| Team Lead | Tech Lead (spesso confusi) |
| Project Lead | Project Manager (nome più carino) |

### Engineering Manager — varianti reali
- **People-first EM:** non coda, 1:1, performance review, hiring. Non tocca il codice.
- **Tech Lead + EM:** ancora nel codice 30-50% del tempo, gestisce 4-6 persone
- **Director of Engineering:** multipli team, budget, roadmap cross-team
Il cliente spesso non sa quale vuole — va estratto con domande specifiche nel kick-off.

### Product Manager vs Product Owner
- **Product Manager:** visione strategica, roadmap, analisi mercato, stakeholder management
- **Product Owner:** priorità backlog, sprint planning, riporta al PM o ai founder
Non sono intercambiabili. Un PO senior non è un PM.

---

## BOOLEANE DI SOURCING (LinkedIn)

### Go + Kubernetes (profilo ideale)
```
("software engineer" OR "backend engineer" OR "platform engineer") AND ("Go" OR "Golang") AND ("Kubernetes" OR "K8s") AND ("Milano" OR "Milan") AND ("AWS" OR "GCP" OR "Azure")
```

### Java/C++ pivot (pool allargato)
```
("senior engineer" OR "staff engineer" OR "tech lead") AND ("Kubernetes" OR "K8s" OR "OpenShift") AND ("Java" OR "C++") AND ("distributed systems" OR "microservices") AND ("Milano" OR "Milan" OR "Lombardia")
```

### GitHub X-Ray (validazione profili LinkedIn)
```
site:github.com ("location" "Milan" OR "Milano") ("Go" OR "Golang") ("kubernetes" OR "k8s")
```

### LinkedIn X-Ray via Google
```
site:linkedin.com/in ("Go" OR "Golang") ("Kubernetes") ("Milan" OR "Milano") -jobs -recruiter -"looking for"
```

### Python backend (non data science)
```
("backend engineer" OR "software engineer" OR "API developer") AND ("Python" OR "Django" OR "FastAPI" OR "Flask") AND ("Milano" OR "Milan") -"data scientist" -"machine learning"
```

### Engineering Manager (people-first)
```
("engineering manager" OR "head of engineering" OR "VP engineering") AND ("people management" OR "1:1" OR "performance review" OR "team lead") AND ("Milano" OR "Milan")
```

---

## POOL SIZE REFERENCE — MERCATO MILANO

| Stack | Profili LinkedIn Milano | Realistically reachable (15-20%) |
|---|---|---|
| Go + K8s (overlap) | ~120-150 | ~15-25 |
| Java Senior + K8s | ~800-1000 | ~120-200 |
| Python Backend Senior | ~400-600 | ~60-120 |
| React Senior | ~500-700 | ~75-140 |
| Full Stack Senior | ~1000+ | ~150-200 |
| DevOps / Platform Eng | ~300-500 | ~45-100 |
| Engineering Manager | ~200-300 | ~30-60 |
| Data Engineer Senior | ~150-250 | ~25-50 |

**Nota:** Il 90%+ dei profili IT è passivo. Il pool "attivo" è una frazione.
La formula del placement è Placement = J × C (qualità JO × numero di contatti).
